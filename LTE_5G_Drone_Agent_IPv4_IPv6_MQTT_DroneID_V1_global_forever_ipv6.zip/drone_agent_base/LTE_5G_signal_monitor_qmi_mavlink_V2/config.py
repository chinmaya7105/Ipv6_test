from pathlib import Path
from datetime import datetime

# ==============================
# SYSTEM CONNECTION CONFIG
# ==============================
STARTUP_WAIT_TIMEOUT = 600       # 10 minutes
STARTUP_RETRY_INTERVAL = 5       # seconds
ENABLE_QMI = True
ENABLE_MAVLINK = True
QMI_DEVICE = None
MAVLINK_BAUD = 115200
WAN_SESSION_MODE = "QMI"   #MODEMMANAGER or QMI

# User-configurable operational settings
AUTO_RECONNECT = True
MAX_RECONNECT_ATTEMPTS = 10
RECONNECT_INTERVAL = 30.0
QMI_LOG_INTERVAL = .3              #in seconds
CSV_MAX_ROWS_PER_FILE = 10000

#===============================
#UTM CONFIG
#===============================

UTM_SERVER_HOST = "80.225.249.137"   #http://80.225.249.137/    UTM server Ip
UTM_SERVER_PING_TIMEOUT = 2


# ==============================
# MQTT
# ==============================
MQTT_ENABLED = True
# Permanent identity of this drone. Change only this value per Jetson/drone.
DRONE_ID = "DRONE001"

# Discovery/telemetry MQTT broker.
# This broker is used only for prototype discovery/telemetry publishing.
MQTT_HOST = "test.mosquitto.org"
MQTT_PORT = 1883
MQTT_USERNAME = ""
MQTT_PASSWORD = ""
MQTT_TOPIC = "drone_telemetry"
MQTT_DISCOVERY_ROOT = "drones"
MQTT_DISCOVERY_INTERVAL = 10.0

# ==============================
# CELLULAR
# ==============================
APN = "airtelgprs.com"
ENABLE_INTERNET_CHECK = True
INTERNET_CHECK_TIMEOUT = 5.0

# ==============================
# FILES
# ==============================
BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
RUN_TIMESTAMP = datetime.now().astimezone().strftime("%Y%m%d_%H%M%S")
CSV_FILE = LOG_DIR / f"telemetry_{RUN_TIMESTAMP}.csv"
SESSION_LOG = LOG_DIR / f"session_{RUN_TIMESTAMP}.log"
