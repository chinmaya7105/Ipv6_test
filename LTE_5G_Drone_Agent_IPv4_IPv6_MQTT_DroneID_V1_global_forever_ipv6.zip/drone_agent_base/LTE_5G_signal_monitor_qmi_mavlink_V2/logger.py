import os
from datetime import datetime
import subprocess
import sys
import threading

class Logger:
    def __init__(self, filename):
        self.filename = filename
        self._cleanup_old_session_logs()

    def _append(self, text):
        with open(self.filename, "a", encoding="utf-8") as f:
            f.write(text)

    def message(self, text, status="OK"):
        self.write("MESSAGE", "", text, status)

    def write(self, title, command="", output="", status="OK"):
        now = datetime.now().astimezone().isoformat(timespec="milliseconds")
        thread_name = threading.current_thread().name
        output = str(output).replace("\r", " ").replace("\n", " ").strip()
        command = str(command).replace("\r", " ").replace("\n", " ").strip()
        text = (f"{now} | "f"{thread_name} | "f"{title} | "f"{status} | "f"{command} | "f"{output}\n")
        self._append(text)
        if status not in ("OK", "SUCCESS"):
            print(f"[{status}] {title}: {output}", flush=True)

    def system_diagnostics(self, reason="QMI/MODEM failure"):
        """Capture kernel and ModemManager diagnostics into the same session log."""
        since = "5 minutes ago"
        commands = [
            ("KERNEL DIAGNOSTICS (dmesg)", ["dmesg", "--level=err,warn", "--time-format=iso"]),
            ("KERNEL JOURNAL (journalctl -k)", ["journalctl", "-k", "--since", since, "--no-pager"]),
            ("MODEMMANAGER JOURNAL", ["journalctl", "-u", "ModemManager", "--since", since, "--no-pager"]),
            ("QMI DEVICE NODES", ["sh", "-c", "ls -l /dev/cdc-wdm* 2>&1 || true"]),
            ("USB DEVICES", ["lsusb"]),
        ]
        self.write("SYSTEM DIAGNOSTICS", "", f"Reason: {reason}", "WARNING")
        for title, command in commands:
            try:
                r = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=15)
                self.write(title, " ".join(command), r.stdout.strip(), "SUCCESS" if r.returncode == 0 else "WARNING")
            except Exception as exc:
                self.write(title, " ".join(command), str(exc), "FAILED")
                
                
    def _cleanup_old_session_logs(self):
        """Keep only the 10 newest session log files in the logs folder."""
        try:
            log_dir = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "logs",
            )

            if not os.path.isdir(log_dir):
                return

            # Only .log files inside the logs folder are considered.
            log_files = []

            for name in os.listdir(log_dir):
                path = os.path.join(log_dir, name)

                if os.path.isfile(path) and name.lower().endswith(".log"):
                    log_files.append(path)

            # Newest first.
            log_files.sort(key=os.path.getmtime, reverse=True)

            # Keep the latest 10 and delete anything older.
            for old_file in log_files[10:]:
                try:
                    os.remove(old_file)
                except OSError:
                    pass

        except Exception:
            # Cleanup must never prevent the application from starting.
            pass
