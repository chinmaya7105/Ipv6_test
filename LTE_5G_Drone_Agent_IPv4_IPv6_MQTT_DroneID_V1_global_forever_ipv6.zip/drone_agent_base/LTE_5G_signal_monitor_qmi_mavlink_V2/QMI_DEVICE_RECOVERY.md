# QMI device recovery and WAN recovery rules

## Why cdc-wdm0 can become cdc-wdm1

`/dev/cdc-wdm0` and `/dev/cdc-wdm1` are dynamic Linux device-node names.
They are not permanent identifiers of the physical modem or USB connector.

A modem can temporarily lose/recreate its USB/QMI control interface after:
- modem firmware reset/recovery
- USB link reset
- USB interface re-enumeration
- driver teardown/recreation
- modem USB composition changes
- modem/ModemManager recovery activity

When the interfaces are recreated, Linux may assign a different free
`cdc-wdmX` number. The physical modem can remain connected to the same
physical USB port.

Therefore this application never permanently assumes `/dev/cdc-wdm0`.

It scans `/dev/cdc-wdm*` and tests each candidate.

## WAN recovery rule

The WAN watchdog is deliberately QMI-first:

1. Find a currently usable `/dev/cdc-wdm*`.
2. Check modem ONLINE.
3. Check SIM READY.
4. Check network registration.
5. Check packet session.
6. If packet session is disconnected, reconnect the Airtel APN.
7. Read the new dynamic QMI IP, subnet mask, gateway and WWAN interface.
8. Compare those values with the Linux interface and default route.
9. If Linux WAN is already correct: **do nothing**.
10. Only if QMI is healthy AND Linux WAN is actually wrong: modify the route.

The watchdog therefore does not blindly rewrite the WAN when a QMI event occurs.

## QMI command recovery

If `/dev/cdc-wdm0` disappears during a signal sample, `qmi.py`:
- detects the missing device,
- scans all `/dev/cdc-wdm*`,
- selects a working device,
- updates `config.QMI_DEVICE`,
- retries the failed qmicli command once.

WAN routing is not changed by this QMI command retry.
