import re
import subprocess
import threading

import config


_utm_ping_lock = threading.Lock()
_utm_ping_thread = None
_utm_ping_status = "NOT_TESTED"
_utm_ping_latency = ""
_utm_last_logged_status = None


def ping_utm_server(logger):
    target = config.UTM_SERVER_HOST
    url = f"http://{target}/"

    ping_status = "FAILED"
    ping_latency = ""

    curl_status = "FAILED"
    curl_latency = ""

    # ---------------------------------------------------------
    # 1. PING
    # ---------------------------------------------------------
    try:
        ping_cmd = [
            "ping",
            "-c", "1",
            "-W", "2",
            target
        ]

        result = subprocess.run(
            ping_cmd,
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0:
            m = re.search(
                r"time[=<]\s*([\d.]+)\s*ms",
                result.stdout
            )

            ping_status = "SUCCESS"
            ping_latency = float(m.group(1)) if m else ""

    except Exception:
        ping_status = "FAILED"
        ping_latency = ""

    # ---------------------------------------------------------
    # 2. CURL
    # ---------------------------------------------------------
    try:
        curl_cmd = [
            "curl",
            "-s",
            "-o", "/dev/null",
            "-w", "%{http_code} %{time_total}",
            "--connect-timeout", "2",
            "--max-time", "5",
            url
        ]

        result = subprocess.run(
            curl_cmd,
            capture_output=True,
            text=True,
            timeout=6
        )

        output = result.stdout.strip()

        if result.returncode == 0:
            parts = output.split()

            if len(parts) >= 2:
                try:
                    http_code = int(parts[0])
                    curl_latency = float(parts[1]) * 1000.0

                    if 200 <= http_code < 400:
                        curl_status = "SUCCESS"

                except ValueError:
                    curl_status = "FAILED"

    except Exception:
        curl_status = "FAILED"
        curl_latency = ""

    # ---------------------------------------------------------
    # 3. FINAL RESULT
    # ---------------------------------------------------------

    # Prefer ICMP latency if ping succeeds
    if ping_status == "SUCCESS":
        return "SUCCESS", ping_latency

    # If ping fails but HTTP works, use CURL latency
    if curl_status == "SUCCESS":
        return "SUCCESS", curl_latency

    # Both failed
    return "FAILED", ""


def _utm_ping_worker(logger):
    global _utm_ping_status, _utm_ping_latency
    global _utm_last_logged_status

    status, latency = ping_utm_server(logger)

    with _utm_ping_lock:
        _utm_ping_status = status
        _utm_ping_latency = latency

        latency_text = (
            f"{latency:.1f} ms"
            if isinstance(latency, (int, float))
            else "--"
        )

        # ALWAYS save to session .log
        logger.write(
            "UTM SERVER",
            config.UTM_SERVER_HOST,
            f"Status: {status}, Latency: {latency_text}",
            "SUCCESS" if status == "SUCCESS" else "FAILED"
        )

        # CONSOLE: print only when status changes
        if status != _utm_last_logged_status:
            print(
                f"[{'SUCCESS' if status == 'SUCCESS' else 'FAILED'}] "
                f"UTM SERVER: Status: {status}, Latency: {latency_text}",
                flush=True
            )

            _utm_last_logged_status = status


def start_utm_ping(logger):
    global _utm_ping_thread

    with _utm_ping_lock:
        if _utm_ping_thread is not None and _utm_ping_thread.is_alive():
            return

        _utm_ping_thread = threading.Thread(
            target=_utm_ping_worker,
            args=(logger,),
            name="UTM-Ping",
            daemon=True
        )
        _utm_ping_thread.start()


def get_utm_result():
    with _utm_ping_lock:
        return _utm_ping_status, _utm_ping_latency
