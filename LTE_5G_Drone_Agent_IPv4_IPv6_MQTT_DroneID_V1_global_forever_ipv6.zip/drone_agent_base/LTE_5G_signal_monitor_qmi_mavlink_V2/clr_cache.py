import os
import shutil
from pathlib import Path


def clear_python_cache():
    """Remove Python __pycache__ directories and .pyc files."""
    project_dir = Path(__file__).resolve().parent

    for path in project_dir.rglob("__pycache__"):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)

    for path in project_dir.rglob("*.pyc"):
        try:
            path.unlink()
        except OSError:
        	pass

#clear_python_cache()

