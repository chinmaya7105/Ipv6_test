# QMI Signal Monitor + MAVLink v10 (no DNS2)

## Main behavior
- QMI device is detected automatically.
- MAVLink FC USB port is detected automatically from `/dev/ttyACM0` and `/dev/ttyACM1` by waiting for a heartbeat.
- No MAVLink port is configured in `config.py`.
- QMI sampling is every `SIGNAL_INTERVAL` seconds (default 1 second).
- MAVLink runs continuously in its own thread and keeps the latest telemetry snapshot.
- Each QMI CSV sample uses the latest MAVLink snapshot available at that QMI sample time.
- `mav_timestamp` is the Jetson receive timestamp for the latest MAVLink message.
- `mavlink_age_ms` is the age of that MAVLink snapshot at the QMI sample timestamp.
- No FC/Jetson clock synchronization is used.
- Detailed QMI/MAVLink command information remains in the per-run session log; console output stays short.

## Enable / disable
In `config.py`:

```python
ENABLE_QMI = True
ENABLE_MAVLINK = True
```

You can run QMI only, MAVLink only, or both.

## Add another QMI command
Open `signal_monitor.py` and add the command in `get_qmi_network_info()`:

```python
rc, output = qmi("--your-qmi-command", logger)
if rc == 0:
    data["your_csv_field"] = parse_your_output(output)
```

Then add the CSV field name to `CSV_FIELDS`.

## Add another MAVLink message
Open `mavlink.py` and add another `elif msg_type == "YOUR_MESSAGE":` block in `_process()`.
Store the values in `self._latest`, then add the corresponding column to `CSV_FIELDS` in `signal_monitor.py`.

## Add a new CSV field
1. Add the field name to `CSV_FIELDS` in `signal_monitor.py`.
2. Populate it from the QMI parser, MAVLink `_process()`, or Linux network information.

A new timestamped CSV file is created for every application execution.


## Automatic cellular WAN
- Airtel APN is taken from `config.py` (`APN = "airtelgprs.com"`).
- QMI packet-session status is checked before starting a new session.
- If already connected, the existing session is preserved.
- WWAN interface is obtained dynamically using `qmicli --get-wwan-iface`.
- IPv4 address, subnet mask, gateway, DNS and MTU are obtained dynamically using `qmicli --wds-get-current-settings`.
- The WWAN interface, IP address and cellular default route are configured from those detected values.
- No fixed `wwan0`, cellular IP, gateway, `1.1.1.1`, or `8.8.8.8` is used.
- WAN verification uses the currently detected cellular gateway and route.
- Recovery retries forever (appropriate for unattended operation) until the cellular WAN becomes healthy.
- Every WAN recovery/configuration event is written to the session log.
- Run the application with sufficient privileges (`sudo python3 main.py`) because Linux interface/route changes require root.

## v6 safety/recovery behavior

- QMI access is serialized with a lock so the signal monitor and WAN watchdog do not hammer the same QMI control endpoint concurrently.
- `/dev/cdc-wdm*` is rediscovered after QMI endpoint loss/re-enumeration.
- WAN recovery is QMI-first: modem -> SIM -> registration -> packet session -> dynamic IP/gateway/interface -> Linux WAN verification.
- Every WAN watchdog interval rechecks the packet session and WAN state. If the Internet test fails, the QMI data session is recycled and the fresh dynamic settings are read before any route change.
- No fixed cellular IP, gateway, or public IP is used.
- MAVLink has an independent serial-port watchdog and automatically rediscovers `/dev/ttyACM*` after a stalled/disconnected FC connection.
- CSV timestamps are timezone-aware local timestamps with millisecond precision. `qmi_timestamp` is the QMI collection-cycle timestamp; `mav_timestamp` is the actual FC-message receive timestamp; `gps_status_timestamp` is the GPS_RAW_INT receive timestamp.
- Session logs capture `dmesg`, `journalctl -k`, `journalctl -u ModemManager`, USB devices and `/dev/cdc-wdm*` when QMI/modem failures occur, with a cooldown to avoid log flooding.


## Single-service IPv4 + IPv6 package

This package runs the existing IPv4 QMI WAN manager and the IPv6 coexistence
setup under one systemd service.

Startup sequence:
1. Dynamically detect the QMI device.
2. Wait for modem, SIM and network registration.
3. Establish/verify the IPv4 QMI data session.
4. Dynamically obtain the WWAN interface and IPv4 settings.
5. Run `qmi_ipv6_wan_jetson_ipv4_ipv6_coexist_final.sh` using the *same*
   dynamically detected QMI device/interface.
6. Verify IPv6 address, IPv6 default route and IPv6 Internet connectivity.
7. Keep both IPv4 and IPv6 under independent watchdogs.
8. Recover automatically after modem/QMI/WWAN changes.

No fixed `/dev/cdc-wdm1` or `wwan0` is required by the combined service. The
validated IPv6 script accepts `QMI_WDM`, `QMI_IFACE` and `QMI_APN` overrides.

### Install on another Ubuntu/Linux PC or Jetson

Extract the package and run:

```bash
cd LTE_5G_signal_monitor_qmi_mavlink_V2
sudo ./install_service.sh
```

Then:

```bash
systemctl status iitb-lte5g.service
journalctl -u iitb-lte5g.service -f
```

The service runs as root because QMI control, WWAN address and route changes
require elevated privileges.

### Configuration

Edit `config.py` before installation if the SIM uses another APN:

```python
APN = "airtelgprs.com"
```

The application continues to use the existing MQTT/MAVLink configuration.
