import shutil
import time
import threading
from datetime import datetime, timezone
import clr_cache
import re
import config

clr_cache.clear_python_cache()
print ("cache cleared..")

# Clear Python cache before loading project modules

import config
from logger import Logger
from qmi import find_qmi_device, qmi
from signal_monitor import init_csv, read_signal, append_timestamp_only_row, prepare_mqtt_data
from mqtt import MQTT
from mavlink import MAVLinkReceiver
from wan import ensure_wan, watchdog_loop, get_interface
from ipv6_manager import ensure_ipv6, watchdog_loop as ipv6_watchdog_loop

# Internal watchdog/diagnostic timing (not user configuration)
WAN_WATCHDOG_INTERVAL = 5.0
SYSTEM_DIAGNOSTIC_COOLDOWN = 30.0
IPV6_WATCHDOG_INTERVAL = 10.0


# ==============================
# DYNAMIC WAN HEALTH HELPERS
# ==============================
# No fixed WAN interface, cellular IP, gateway, DNS server, or public test IP.
# QMI supplies the current IPv4 settings after the packet session is active.

def _run_cmd(cmd, timeout=10):
    import subprocess
    return subprocess.run(
        cmd, text=True, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT, timeout=timeout
    )

def get_dynamic_qmi_settings(qmi_device):
    """Return current QMI IPv4 settings dynamically."""
    import re
    r = _run_cmd(
        ["qmicli", "-d", qmi_device, "--wds-get-current-settings"],
        timeout=10
    )
    if r.returncode != 0:
        raise RuntimeError(r.stdout.strip() or "Unable to read QMI current settings")

    out = r.stdout

    def value(pattern):
        m = re.search(pattern, out, re.I)
        return m.group(1).strip() if m else None

    return {
        "ip": value(r"IPv4 address:\s*([0-9.]+)"),
        "mask": value(r"IPv4 subnet mask:\s*([0-9.]+)"),
        "gateway": value(r"IPv4 gateway address:\s*([0-9.]+)"),
        "dns1": value(r"IPv4 primary DNS:\s*([0-9.]+)"),
        "dns2": value(r"IPv4 secondary DNS:\s*([0-9.]+)"),
        "mtu": value(r"MTU:\s*(\d+)"),
    }

def get_dynamic_wwan_interface(qmi_device):
    r = _run_cmd(["qmicli", "-d", qmi_device, "--get-wwan-iface"], timeout=10)
    if r.returncode != 0:
        raise RuntimeError(r.stdout.strip() or "Unable to determine WWAN interface")
    iface = r.stdout.strip().splitlines()[-1].strip()
    if not iface:
        raise RuntimeError("QMI returned an empty WWAN interface")
    return iface

def configure_dynamic_cellular_route(qmi_device, log_fn=print):
    """
    Configure the cellular route from QMI-provided dynamic values.
    Does NOT ping the gateway. Many cellular gateways do not answer ICMP.
    """
    import subprocess
    s = get_dynamic_qmi_settings(qmi_device)
    iface = get_dynamic_wwan_interface(qmi_device)

    ip = s["ip"]
    gateway = s["gateway"]
    mask = s["mask"]

    if not ip or not gateway:
        raise RuntimeError(f"QMI did not provide usable IP/gateway: {s}")

    # Bring interface up.
    subprocess.run(["ip", "link", "set", "dev", iface, "up"], check=False)

    # Calculate prefix from QMI subnet mask.
    import ipaddress
    prefix = ipaddress.IPv4Network("0.0.0.0/" + mask).prefixlen

    # Add the exact dynamically assigned address if it is not already present.
    addr = f"{ip}/{prefix}"
    existing = _run_cmd(["ip", "-4", "addr", "show", "dev", iface], timeout=5).stdout
    if addr not in existing:
        subprocess.run(
            ["ip", "-4", "addr", "replace", addr, "dev", iface],
            check=False
        )

    # Add the connected route. This uses the dynamic IP/subnet only.
    network = str(ipaddress.IPv4Network(f"{ip}/{prefix}", strict=False))
    subprocess.run(
        ["ip", "route", "replace", network, "dev", iface, "src", ip],
        check=False
    )

    # Prefer cellular WAN without hard-coding any cellular address/interface.
    # Metric is only route priority, not an IP.
    subprocess.run(
        ["ip", "route", "replace", "default", "via", gateway,
         "dev", iface, "src", ip, "metric", "10"],
        check=False
    )

    route = _run_cmd(["ip", "route", "show", "default", "dev", iface], timeout=5).stdout.strip()

    log_fn(
        f"[RECOVERY] WAN CONFIGURATION: interface={iface}, "
        f"ip={addr}, gateway={gateway}, "
        f"dns1={s.get('dns1')}, dns2={s.get('dns2')}, route={route}"
    )

    return {
        "interface": iface,
        "ip": ip,
        "prefix": prefix,
        "gateway": gateway,
        "dns1": s.get("dns1"),
        "dns2": s.get("dns2"),
        "mtu": s.get("mtu"),
        "route": route,
    }

def verify_dynamic_wan(qmi_device):
    """
    Verify WAN using the QMI session, dynamic interface/IP and routing.
    No fixed public IP and no gateway ICMP ping.
    """
    import ipaddress

    s = get_dynamic_qmi_settings(qmi_device)
    iface = get_dynamic_wwan_interface(qmi_device)

    if not s["ip"] or not s["gateway"]:
        return False, "QMI IP/gateway unavailable", {"interface": iface, **s}

    addr_text = _run_cmd(["ip", "-4", "addr", "show", "dev", iface], timeout=5).stdout
    route_text = _run_cmd(["ip", "route", "show", "default", "dev", iface], timeout=5).stdout

    prefix = ipaddress.IPv4Network("0.0.0.0/" + s["mask"]).prefixlen
    ip_present = re.search(rf"\binet\s+{re.escape(s['ip'])}/{prefix}\b", addr_text) is not None
    route_present = bool(route_text.strip()) and s["gateway"] in route_text

    details = {
        "interface": iface,
        "ip": s["ip"],
        "gateway": s["gateway"],
        "dns1": s.get("dns1"),
        "dns2": s.get("dns2"),
        "ip_present": ip_present,
        "route_present": route_present,
        "route": route_text.strip(),
    }

    if not ip_present:
        return False, "Dynamic cellular IP is not configured on WWAN interface", details

    if not route_present:
        return False, "Dynamic cellular default route is missing", details

    return True, "Dynamic cellular WAN configuration is healthy", details




def console_status(message):
    print(message, flush=True)


def run_check(logger, label, command):
    rc, output = qmi(command, logger)
    if rc == 0:
        console_status(f"{label}... OK")
        return True, output
    console_status(f"{label}... ERROR")
    return False, output


def packet_session_status(logger):
    ok, output = run_check(
        logger, "Checking packet session", "--wds-get-packet-service-status"
    )
    if not ok:
        return False

    match = re.search(
        r"Connection status:\s*['\"]([^'\"]+)['\"]",
        output,
        re.IGNORECASE,
    )

    status = match.group(1).strip().lower() if match else ""

    console_status(
        f"Packet session: {'CONNECTED' if status == 'connected' else 'DISCONNECTED'}"
    )

    return status == "connected"


def modem_status(logger):
    ok, output = run_check(
        logger, "Checking modem", "--dms-get-operating-mode"
    )
    if not ok:
        return False
    online = "online" in output.lower()
    console_status(f"Modem: {'ONLINE' if online else 'NOT ONLINE'}")
    return online


def sim_status(logger):
    ok, output = run_check(
        logger, "Checking SIM", "--uim-get-card-status"
    )
    if not ok:
        return False
    ready = "Application state: 'ready'" in output
    console_status(f"SIM: {'READY' if ready else 'NOT READY'}")
    return ready


def network_status(logger):
    ok, output = run_check(
        logger, "Checking network registration", "--nas-get-serving-system"
    )
    if not ok:
        console_status("Network registration: ERROR")
        return False
    text = output.lower()
    registered = any(word in text for word in ("registered", "home", "roaming", "current network"))
    console_status(f"Network registration: {'REGISTERED' if registered else 'NOT REGISTERED'}")
    return registered


def main():
    logger = Logger(config.SESSION_LOG)
    init_csv()
    console_status("QMI Signal Monitor started")
    logger.write("APPLICATION START", "", "Starting monitor", "SUCCESS")

    # ------------------------------------------------------------
    # QMI startup
    # ------------------------------------------------------------
    if config.ENABLE_QMI:
        if shutil.which("qmicli") is None:
            console_status("[ERROR] QMI dependency: qmicli not found")
            logger.write("DEPENDENCY CHECK", "command -v qmicli", "qmicli not found", "FAILED")
            return

        console_status("Detecting QMI device...")
        device = find_qmi_device(logger)
        if not device:
            console_status("Detecting QMI device... ERROR")
            logger.write("QMI DEVICE", "ls /dev/cdc-wdm*", "No working QMI device found", "FAILED")
            return

        config.QMI_DEVICE = device
        console_status(f"Detecting QMI device... OK ({device})")
        logger.write("QMI DEVICE SELECTED", "", device, "SUCCESS")
        """modem_status(logger)
        sim_status(logger)
        network_status(logger)
        packet_session_status(logger)"""

        startup_deadline = time.monotonic() + config.STARTUP_WAIT_TIMEOUT

        while True:
            if time.monotonic() >= startup_deadline:
                logger.write("STARTUP","","Startup wait timeout exceeded","FAILED",)
                console_status("Startup timeout: modem/SIM/network/data not ready")
                return
                
            if not modem_status(logger):
            	time.sleep(config.STARTUP_RETRY_INTERVAL)
            	continue

            if not sim_status(logger):
            	console_status("SIM not ready... waiting")
            	time.sleep(config.STARTUP_RETRY_INTERVAL)
            	continue

            if not network_status(logger):
                console_status("Network not registered... waiting")
                time.sleep(config.STARTUP_RETRY_INTERVAL)
                continue
                
            '''if not packet_session_status(logger):
                console_status("Packet session not connected... waiting")
                time.sleep(config.STARTUP_RETRY_INTERVAL)
                continue'''
            break
            
        packet_session_status(logger)       #kept outside since the data session process wait until its start packet connection
        
        # --------------------------------------------------------
        # Automatic cellular WAN configuration
        # - preserves an already healthy session
        # - detects the QMI WWAN interface dynamically
        # - obtains the current IP/gateway/mask from QMI
        # - configures the interface and cellular default route
        # - retries forever if the connection is lost
        # - never uses a fixed WAN IP or fixed public test IP
        # --------------------------------------------------------
        console_status("Configuring WAN...")
        wan_ok, wan_interface, wan_settings = ensure_wan(logger, initial_startup=True)
        if wan_ok:
            console_status(
                f"Configuring WAN... OK ({wan_interface}, "
                f"IP={wan_settings.get('ip')}, "
                f"GW={wan_settings.get('gateway')})"
            )
        else:
            console_status("Configuring WAN... ERROR")
            logger.write(
                "WAN CONFIGURATION",
                "automatic dynamic WAN recovery",
                "WAN could not be established",
                "FAILED"
            )
            return
        # IPv6 coexistence: use the exact QMI device/interface dynamically
        # selected by the IPv4 WAN layer. No fixed cdc-wdmX/wwanX is used.
        ipv6_stop = threading.Event()
        ipv6_state = {"qmi_device": config.QMI_DEVICE, "interface": wan_interface}

        def get_ipv6_wan_state():
            ipv6_state["qmi_device"] = config.QMI_DEVICE or ipv6_state.get("qmi_device", "")
            try:
                detected_iface = get_interface(logger)
                if detected_iface:
                    ipv6_state["interface"] = detected_iface
            except Exception:
                pass
            return dict(ipv6_state)

        console_status("Configuring IPv6 coexistence...")
        ipv6_ok, ipv6_detail = ensure_ipv6(
            logger, config.QMI_DEVICE, wan_interface, config.APN
        )
        console_status(
            f"Configuring IPv6 coexistence... {'OK' if ipv6_ok else 'WARNING'} ({ipv6_detail})"
        )

        ipv6_thread = threading.Thread(
            target=ipv6_watchdog_loop,
            args=(logger, ipv6_stop, get_ipv6_wan_state, config.APN),
            kwargs={"interval": IPV6_WATCHDOG_INTERVAL},
            daemon=True,
            name="ipv6-wan-watchdog",
        )
        ipv6_thread.start()
    else:
        ipv6_stop = threading.Event()
        ipv6_thread = None
        console_status("QMI monitoring... DISABLED")
        logger.write("QMI MONITORING", "", "Disabled in config", "SKIPPED")

    # ------------------------------------------------------------
    # MAVLink startup: port is detected inside MAVLinkReceiver.
    # ------------------------------------------------------------
    mavlink = MAVLinkReceiver(logger) if config.ENABLE_MAVLINK else None
    mavlink_ok = False

    if config.ENABLE_MAVLINK:
        console_status("Starting MAVLink receiver...")
        mavlink_ok = mavlink.start()
        if mavlink_ok:
            console_status(f"Starting MAVLink receiver... OK ({mavlink.port})")
        else:
            console_status("Starting MAVLink receiver... ERROR")
    else:
        console_status("MAVLink monitoring... DISABLED")
        logger.write("MAVLINK MONITORING", "", "Disabled in config", "SKIPPED")

    # ------------------------------------------------------------
    # MQTT
    # ------------------------------------------------------------
    mqtt_published = False
    mqtt = MQTT(logger)
    
    if mqtt.client:
        console_status("Connecting MQTT... OK")
    elif config.MQTT_ENABLED:
        console_status("Connecting MQTT... ERROR")
    else:
        console_status("Connecting MQTT... DISABLED")

    if config.ENABLE_QMI:
        console_status("Monitoring signal data...")
    if config.ENABLE_MAVLINK and mavlink_ok:
        console_status("Monitoring MAVLink data...")

    qmi_error_active = False
    last_system_diag = 0.0
    wan_error_active = False
    mav_error_active = config.ENABLE_MAVLINK and not mavlink_ok
    mqtt_error_active = config.MQTT_ENABLED and mqtt.client is None

    # Independent cellular/WAN watchdog.
    # MAVLink recovery NEVER calls this watchdog, and WAN recovery NEVER
    # restarts MAVLink. Each subsystem recovers independently.
    wan_stop = threading.Event()
    wan_thread = None
    if config.ENABLE_QMI:
        wan_thread = threading.Thread(
            target=watchdog_loop,
            args=(logger, wan_stop),
            kwargs={"interval": WAN_WATCHDOG_INTERVAL},
            daemon=True,
            name="wan-watchdog",
        )
        wan_thread.start()

    try:
        while True:
            # One timestamp is taken immediately before the QMI sample.
            # The latest MAVLink snapshot is correlated to this same Jetson clock.
            qmi_sample_time = datetime.now(timezone.utc)

            if config.ENABLE_MAVLINK and mavlink_ok:
                mav_data = mavlink.get_latest(qmi_sample_time)
                mav_data_ok = bool(mav_data.get("mav_timestamp"))

                if not mav_data_ok and not mav_error_active:
                    console_status("[ERROR] MAVLink data reception stopped")
                    logger.message("MAVLink data reception stopped")
                    mav_error_active = True
                elif mav_data_ok and mav_error_active:
                    console_status("[OK] MAVLink data reception recovered")
                    logger.message("MAVLink data reception recovered")
                    mav_error_active = False
            else:
                mav_data = {}

            if config.ENABLE_QMI:
                previous_qmi_device = config.QMI_DEVICE
                record = read_signal(logger, mav_data, sample_time=qmi_sample_time)
                if config.QMI_DEVICE and config.QMI_DEVICE != previous_qmi_device:
                    console_status(
                        f"[RECOVERY] QMI device changed: "
                        f"{previous_qmi_device} -> {config.QMI_DEVICE}"
                    )
                    logger.message(
                        f"QMI device changed: {previous_qmi_device} -> {config.QMI_DEVICE}"
                    )
                
                if record:
                    if qmi_error_active:
                        console_status("[OK] QMI signal monitoring recovered")
                        logger.message("QMI signal monitoring recovered")
                        qmi_error_active = False
                    
                    #mqtt.publish(record)    # publish all record together
                    
                    
                    #format the data then publish
                    mqtt_data = prepare_mqtt_data(record)
                    # Add the permanent Drone ID to the existing MQTT payloads.
                    # Existing QMI/MAVLink collection and WAN/IPv6 processes are unchanged.
                    for payload in mqtt_data.values():
                        payload["drone_id"] = config.DRONE_ID
                    try:
                        mqtt.publish(f"{config.MQTT_TOPIC}/telemetry", mqtt_data["telemetry"])
                        mqtt.publish(f"{config.MQTT_TOPIC}/signal", mqtt_data["signal"])
                        mqtt.publish(f"{config.MQTT_TOPIC}/network", mqtt_data["network"])
                        # Discovery is retained and internally throttled. It publishes
                        # the current dynamic IPv6 whenever it changes.
                        mqtt.publish_discovery(wan_interface)
                    
                    
                        if mqtt_published == False:
                            console_status("[MQTT] DATA PUBLISHED")
                            mqtt_published = True
                    
                    except Exception as e:
                        mqtt_published = False
                        console_status(f"[ERROR] MQTT DATA PUBLISH FAILED: {e}")
                        logger.message(f"MQTT data publishing failed: {e}")
                    
                else:
                    if not qmi_error_active:
                        console_status("[ERROR] QMI signal monitoring failed")
                        logger.message("QMI signal monitoring failed")
                        qmi_error_active = True
                    import time as _time
                    if _time.monotonic() - last_system_diag >= SYSTEM_DIAGNOSTIC_COOLDOWN:
                        logger.system_diagnostics("QMI signal monitoring failure / possible modem or USB-QMI disruption")
                        last_system_diag = _time.monotonic()

            if config.MQTT_ENABLED and mqtt.client is None and not mqtt_error_active:
                console_status("[ERROR] MQTT connection unavailable")
                logger.message("MQTT connection unavailable")
                mqtt_error_active = True

            time.sleep(config.QMI_LOG_INTERVAL)

    except KeyboardInterrupt:
        console_status("Application stopped by user")
        logger.write("APPLICATION STOP", "", "Stopped by user", "SUCCESS")
    finally:
        wan_stop.set()
        if wan_thread and wan_thread.is_alive():
            wan_thread.join(timeout=2)
        if 'ipv6_stop' in locals():
            ipv6_stop.set()
        if 'ipv6_thread' in locals() and ipv6_thread and ipv6_thread.is_alive():
            ipv6_thread.join(timeout=2)
        if mavlink:
            mavlink.stop()
        mqtt.close()


if __name__ == "__main__":
    main()
