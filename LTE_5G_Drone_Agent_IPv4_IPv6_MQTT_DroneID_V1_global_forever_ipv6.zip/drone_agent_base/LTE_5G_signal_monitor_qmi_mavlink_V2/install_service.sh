#!/usr/bin/env bash
set -euo pipefail

APP_NAME="iitb-lte5g"
INSTALL_DIR="/opt/iitb-lte5g"
SERVICE_FILE="${APP_NAME}.service"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run as root: sudo ./install_service.sh"
    exit 1
fi

echo "=== Installing IITB LTE/5G QMI IPv4+IPv6 service ==="

apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y     libqmi-utils python3-pip python3-serial iproute2 iputils-ping systemd

if python3 -m pip install --break-system-packages pymavlink paho-mqtt; then
    :
elif python3 -m pip install pymavlink paho-mqtt; then
    :
else
    echo "ERROR: Python dependency installation failed."
    exit 1
fi

mkdir -p "${INSTALL_DIR}"
cp -a ./* "${INSTALL_DIR}/"
chmod 0755 "${INSTALL_DIR}"/*.sh "${INSTALL_DIR}"/*.py

# The application needs root for QMI, interface and route configuration.
install -m 0644 "${INSTALL_DIR}/${SERVICE_FILE}" "/etc/systemd/system/${SERVICE_FILE}"

systemctl daemon-reload
systemctl enable "${SERVICE_FILE}"
systemctl restart "${SERVICE_FILE}"

echo
echo "=== Installation complete ==="
echo "Service : ${SERVICE_FILE}"
echo "Status  : systemctl status ${SERVICE_FILE}"
echo "Logs    : journalctl -u ${SERVICE_FILE} -f"
echo
systemctl --no-pager --full status "${SERVICE_FILE}" || true
