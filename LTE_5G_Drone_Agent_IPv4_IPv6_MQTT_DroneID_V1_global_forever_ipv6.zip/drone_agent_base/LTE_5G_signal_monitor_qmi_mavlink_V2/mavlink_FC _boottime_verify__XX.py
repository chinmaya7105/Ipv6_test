import csv
import glob
import os
import threading
import time
from datetime import datetime, timezone

import config

try:
    from pymavlink import mavutil
except ImportError:
    mavutil = None


def now_local_iso():
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


class MAVLinkReceiver:
    """Continuous MAVLink receiver with independent reconnect watchdog."""

    def __init__(self, logger):
        self.logger = logger
        self._lock = threading.Lock()
        self._running = False
        self._thread = None
        self._connection = None
        self.port = ""
        self.last_receive_time = None
        self.latest_telemetry_time = None
        self.latest_gps_status_time = None

        # MAVLink freshness verification (does not affect port detection)
        self._rx_count = 0
        self._verification_csv = None
        self._verification_writer = None
        self._verification_last_seq = None
        self._verification_last_fc_time = None
        self._verification_lock = threading.Lock()

        self._latest = {
            "mav_timestamp": "",
            "gps_status_timestamp": "",
            "mavlink_age_ms": "",
            "mavlink_seq": "",
            "fc_time_boot_ms": "",
            "rx_count": 0,
            "gps_lat": "",
            "gps_lon": "",
            "altitude_msl_m": "",
            "relative_altitude_m": "",
            "ground_speed_mps": "",
            "heading_deg": "",
            "gps_fix_type": "",
            "satellites_visible": "",
        }

    def _open_verification_csv(self):
        """Open a separate CSV for MAVLink freshness verification."""
        filename = "mavlink_verification.csv"
        try:
            new_file = not os.path.exists(filename)
            self._verification_csv = open(
                filename, "a", newline="", buffering=1
            )
            fields = [
                "pc_rx_time",
                "mavlink_seq",
                "fc_time_boot_ms",
                "rx_count",
                "gps_lat",
                "gps_lon",
                "altitude_msl_m",
                "relative_altitude_m",
                "ground_speed_mps",
                "heading_deg",
                "gps_fix_type",
                "satellites_visible",
                "fc_timestamp_changed",
                "seq_changed",
            ]
            self._verification_writer = csv.DictWriter(
                self._verification_csv,
                fieldnames=fields,
            )
            if new_file:
                self._verification_writer.writeheader()
            self._verification_csv.flush()
        except Exception as exc:
            self._verification_csv = None
            self._verification_writer = None
            self.logger.write(
                "MAVLINK VERIFICATION",
                filename,
                f"Could not open verification CSV: {exc}",
                "WARNING",
            )

    def _write_verification_row(self, msg, rx_local):
        """Log the packet received by this existing MAVLink receiver."""
        if self._verification_writer is None:
            return

        try:
            seq = msg.get_seq()
        except Exception:
            seq = ""

        msg_type = msg.get_type()

        # Only GLOBAL_POSITION_INT carries the FC boot-time field used here.
        fc_time_boot_ms = ""
        if msg_type == "GLOBAL_POSITION_INT":
            fc_time_boot_ms = getattr(msg, "time_boot_ms", "")

        with self._verification_lock:
            self._rx_count += 1

            seq_changed = (
                ""
                if self._verification_last_seq is None
                else seq != self._verification_last_seq
            )

            # We only compare FC boot time when this packet contains it.
            fc_timestamp_changed = (
                ""
                if fc_time_boot_ms == "" or self._verification_last_fc_time is None
                else fc_time_boot_ms != self._verification_last_fc_time
            )

            row = {
                "pc_rx_time": rx_local,
                "mavlink_seq": seq,
                "fc_time_boot_ms": fc_time_boot_ms,
                "rx_count": self._rx_count,
                "gps_lat": self._latest.get("gps_lat", ""),
                "gps_lon": self._latest.get("gps_lon", ""),
                "altitude_msl_m": self._latest.get("altitude_msl_m", ""),
                "relative_altitude_m": self._latest.get("relative_altitude_m", ""),
                "ground_speed_mps": self._latest.get("ground_speed_mps", ""),
                "heading_deg": self._latest.get("heading_deg", ""),
                "gps_fix_type": self._latest.get("gps_fix_type", ""),
                "satellites_visible": self._latest.get("satellites_visible", ""),
                "fc_timestamp_changed": fc_timestamp_changed,
                "seq_changed": seq_changed,
            }

            self._verification_writer.writerow(row)

            self._verification_last_seq = seq
            if fc_time_boot_ms != "":
                self._verification_last_fc_time = fc_time_boot_ms

    def _close_verification_csv(self):
        with self._verification_lock:
            if self._verification_csv is not None:
                try:
                    self._verification_csv.flush()
                    self._verification_csv.close()
                except Exception:
                    pass
            self._verification_csv = None
            self._verification_writer = None

    def _candidate_ports(self):
        """Return detected direct USB MAVLink serial ports."""
        return sorted(glob.glob("/dev/ttyACM*"))

    def _candidate_udp_ports(self):
        """
        Dynamically discover local MAVLink UDP output ports.

        No MAVProxy UDP port number is hard-coded. First inspect running
        MAVProxy command lines for --out=udp:<host>:<port>, then also inspect
        locally bound UDP ports with `ss` as a fallback.
        """
        ports = set()

        # 1) Discover ports directly from running MAVProxy command lines.
        try:
            import re
            import subprocess

            result = subprocess.run(
                ["ps", "-eo", "args="],
                capture_output=True,
                text=True,
                timeout=2.0,
                check=False,
            )

            # Examples:
            # --out=udp:127.0.0.1:14559
            # --out=udp:0.0.0.0:14559
            # --out=udp:14559
            pattern = re.compile(
    		r"--out=udp:(?:[^\s:]+:)?(\d+)"
	    )

            for line in result.stdout.splitlines():
                if "mavproxy" not in line.lower():
                    continue
                for match in pattern.finditer(line):
                    ports.add(int(match.group(1)))

        except Exception as exc:
            self.logger.write(
                "MAVLINK UDP DETECTION",
                "MAVProxy process scan",
                str(exc),
                "WARNING",
            )

        # 2) Also inspect locally bound/listening UDP ports.
        try:
            import re
            import subprocess

            result = subprocess.run(
                ["ss", "-u", "-ln"],
                capture_output=True,
                text=True,
                timeout=2.0,
                check=False,
            )

            pattern = re.compile(
    		r"(?:127\.0\.0\.1|0\.0\.0\.0|\*|\[::\]|::):(\d+)$"
	    )

            for line in result.stdout.splitlines():
                fields = line.split()
                if len(fields) < 5:
                    continue
                match = pattern.search(fields[4])
                if match:
                    ports.add(int(match.group(1)))

        except Exception as exc:
            self.logger.write(
                "MAVLINK UDP DETECTION",
                "ss UDP scan",
                str(exc),
                "WARNING",
            )

        return sorted(ports)

    def _test_connection(self, connection, source):
        """Return True only when the candidate produces a MAVLink heartbeat."""
        try:
            self.logger.write(
                "MAVLINK DEVICE TEST",
                source,
                "Waiting for MAVLink heartbeat",
                "RUNNING",
            )

            heartbeat = connection.wait_heartbeat(
                timeout=MAVLINK_RECEIVE_TIMEOUT
            )

            if heartbeat is not None:
                self.logger.write(
                    "MAVLINK DEVICE SELECTED",
                    source,
                    "MAVLink heartbeat received",
                    "SUCCESS",
                )
                return True

            self.logger.write(
                "MAVLINK DEVICE TEST",
                source,
                f"No heartbeat within {MAVLINK_RECEIVE_TIMEOUT:.0f} seconds",
                "FAILED",
            )

        except Exception as exc:
            self.logger.write(
                "MAVLINK DEVICE TEST",
                source,
                str(exc),
                "FAILED",
            )

        return False

    def _detect_udp(self):
        """Try every dynamically discovered UDP port and select real MAVLink."""
        if mavutil is None:
            return None, None

        ports = self._candidate_udp_ports()

        if not ports:
            self.logger.write(
                "MAVLINK UDP DETECTION",
                "local UDP",
                "No UDP ports detected",
                "INFO",
            )
            return None, None

        self.logger.write(
            "MAVLINK UDP DETECTION",
            str(ports),
            "Testing dynamically detected UDP ports",
            "RUNNING",
        )

        for port in ports:
            source = f"UDP:127.0.0.1:{port}"
            connection = None

            try:
                connection = mavutil.mavlink_connection(
                    f"udpin:127.0.0.1:{port}",
                    autoreconnect=False,
                )

                if self._test_connection(connection, source):
                    return source, connection

            except Exception as exc:
                self.logger.write(
                    "MAVLINK UDP TEST",
                    source,
                    str(exc),
                    "FAILED",
                )

            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass

        return None, None

    def _detect_acm(self):
        """Fallback to direct USB ACM MAVLink ports."""
        ports = self._candidate_ports()

        if not ports:
            self.logger.write(
                "MAVLINK DEVICE DETECTION",
                "/dev/ttyACM*",
                "No ACM serial device detected",
                "FAILED",
            )
            return None, None

        for port in ports:
            connection = None

            try:
                connection = mavutil.mavlink_connection(
                    port,
                    baud=config.MAVLINK_BAUD,
                    autoreconnect=False,
                )

                if self._test_connection(connection, port):
                    return port, connection

            except Exception as exc:
                self.logger.write(
                    "MAVLINK DEVICE TEST",
                    port,
                    str(exc),
                    "FAILED",
                )

            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass

        return None, None

    def _detect_port(self):
        """
        Universal MAVLink discovery.

        Priority:
          1. Dynamically detected MAVProxy/local UDP MAVLink.
          2. Direct /dev/ttyACM* USB MAVLink fallback.

        A UDP port is selected only after a real MAVLink heartbeat is received.
        """
        if mavutil is None:
            return None, None

        self.logger.write(
            "MAVLINK DEVICE DETECTION",
            "UDP -> ACM",
            "Starting universal MAVLink source discovery",
            "RUNNING",
        )

        # Prefer UDP so we never compete with MAVProxy for /dev/ttyACM0.
        port, connection = self._detect_udp()

        if connection is not None:
            return port, connection

        self.logger.write(
            "MAVLINK DEVICE DETECTION",
            "/dev/ttyACM*",
            "No working MAVLink UDP source; falling back to USB ACM",
            "RECOVERY",
        )

        return self._detect_acm()

    def start(self):
        if mavutil is None:
            self.logger.write("MAVLINK START", "", "pymavlink is not installed", "FAILED")
            return False
        self.port, self._connection = self._detect_port()
        if not self._connection:
            self.logger.write("MAVLINK START", "UDP -> /dev/ttyACM*", "No working MAVLink source detected", "FAILED")
            return False
        self._running = True
        self._open_verification_csv()
        self._thread = threading.Thread(target=self._loop, name="MAVLinkThread", daemon=True)
        self._thread.start()
        self.logger.write("MAVLINK START", self.port, "Receiver thread started", "SUCCESS")
        return True

    def _close_connection(self):
        c = self._connection
        self._connection = None
        if c:
            try: c.close()
            except Exception: pass

    def _recover(self):
        if not self._running:
            return False
        self.logger.write("MAVLINK RECOVERY", "dynamic UDP -> ACM discovery", "Attempting MAVLink reconnect", "RECOVERY")
        self._close_connection()
        port, conn = self._detect_port()
        if conn:
            self.port = port
            self._connection = conn
            self.logger.write("MAVLINK RECOVERY", port, "MAVLink connection recovered", "SUCCESS")
            return True
        self.logger.write("MAVLINK RECOVERY", "UDP -> /dev/ttyACM*", "No working MAVLink source found; retry next watchdog cycle", "WARNING")
        return False

    def _loop(self):
        watchdog = max(2.0, float(MAVLINK_WATCHDOG_TIMEOUT))
        next_recovery = 0.0
        while self._running:
            try:
                if self._connection is None:
                    self._recover()
                    time.sleep(1)
                    continue
                msg = self._connection.recv_match(blocking=True, timeout=MAVLINK_RECEIVE_TIMEOUT)
                now = datetime.now(timezone.utc)
                if msg is not None:
                    self._process(msg)
                elif self.last_receive_time is not None and (now - self.last_receive_time).total_seconds() > watchdog:
                    if time.monotonic() >= next_recovery:
                        self.logger.write("MAVLINK WATCHDOG", self.port, f"No MAVLink message for > {watchdog:.1f}s", "WARNING")
                        self._recover()
                        next_recovery = time.monotonic() + 1.0
            except Exception as exc:
                self.logger.write("MAVLINK RECEIVE", self.port, str(exc), "FAILED")
                self._recover()
                time.sleep(1)

    def _process(self, msg):
        msg_type = msg.get_type()
        rx_utc = datetime.now(timezone.utc)
        rx_local = rx_utc.astimezone().isoformat(timespec="milliseconds")

        try:
            mavlink_seq = msg.get_seq()
        except Exception:
            mavlink_seq = ""

        with self._lock:
            self.last_receive_time = rx_utc

            # Packet-level information from the same message received by
            # the existing MAVLinkThread.
            self._latest["mavlink_seq"] = mavlink_seq

            if msg_type == "GLOBAL_POSITION_INT":
                self._latest.update({
                    "gps_lat": msg.lat / 1e7,
                    "gps_lon": msg.lon / 1e7,
                    "altitude_msl_m": msg.alt / 1000.0,
                    "relative_altitude_m": msg.relative_alt / 1000.0,
                    "ground_speed_mps": ((msg.vx ** 2 + msg.vy ** 2) ** 0.5) / 100.0,
                    "heading_deg": msg.hdg / 100.0 if msg.hdg != 65535 else "",
                    "mav_timestamp": rx_local,
                    "fc_time_boot_ms": getattr(msg, "time_boot_ms", ""),
                })
                self.latest_telemetry_time = rx_utc

            elif msg_type == "GPS_RAW_INT":
                self._latest.update({
                    "gps_fix_type": msg.fix_type,
                    "satellites_visible": msg.satellites_visible,
                    "gps_status_timestamp": rx_local,
                })
                self.latest_gps_status_time = rx_utc

        # Write after _latest has been updated so the verification CSV uses
        # the same latest telemetry state as the normal application.
        self._write_verification_row(msg, rx_local)

    def get_latest(self, reference_time=None):
        with self._lock:
            data = dict(self._latest)
            position_time = self.latest_telemetry_time
        if reference_time is not None and position_time is not None:
            data["mavlink_age_ms"] = round(max(0.0, (reference_time - position_time).total_seconds() * 1000.0), 3)
        return data

    def stop(self):
        self._running = False
        self._close_connection()
        if self._thread:
            self._thread.join(timeout=2)
        self._close_verification_csv()

# Internal MAVLink safety timing (not user configuration)
MAVLINK_RECEIVE_TIMEOUT = 3.0
MAVLINK_WATCHDOG_TIMEOUT = 5.0
