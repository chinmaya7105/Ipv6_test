#!/bin/bash
set -e

sudo apt update
sudo apt install -y libqmi-utils python3-pip python3-serial

# Install Python packages for the same Python interpreter used by the service.
# If the distro pip supports PEP 668, --break-system-packages is required.
if sudo python3 -m pip install --break-system-packages pymavlink paho-mqtt; then
    :
elif sudo python3 -m pip install pymavlink paho-mqtt; then
    :
elif python3 -m pip install --user pymavlink paho-mqtt; then
    echo "[WARNING] Python packages installed for the current user. A systemd service
using another user may need the packages installed for that service user."
else
    echo "[ERROR] Could not install pymavlink/paho-mqtt"
    exit 1
fi

qmicli --version
python3 -c "from pymavlink import mavutil; print('pymavlink: OK')"
python3 -c "import serial; print('pyserial: OK')"
python3 -c "import paho.mqtt.client; print('paho-mqtt: OK')"
