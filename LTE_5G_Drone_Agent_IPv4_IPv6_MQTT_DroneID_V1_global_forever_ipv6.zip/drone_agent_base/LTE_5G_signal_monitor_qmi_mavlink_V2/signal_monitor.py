
import csv
import re
import subprocess
from datetime import datetime, timezone
import os
import config
from qmi import qmi
from utm import start_utm_ping, get_utm_result

CSV_FIELDS = [
    "timestamp",
    "qmi_timestamp",
    "mav_timestamp",
    "gps_status_timestamp",
    "mavlink_age_ms",
    "fc_time_boot_ms",
    "gps_lat",
    "gps_lon",
    "altitude_msl_m",
    "relative_altitude_m",
    "ground_speed_mps",
    "heading_deg",
    "gps_fix_type",
    "satellites_visible",
    "fc_sysid",
    "fc_armed",
    
    "qmi_device",
    "wan_interface",
    "apn",
    "packet_session",
    "registration_state",
    "cs_attach_state",
    "ps_attach_state",
    
    "radio_interfaces",
    "mcc",
    "mnc",
    "cell_id",
    "pci",
    "lte_rssi_dbm",
    "lte_rsrq_db",
    "lte_rsrp_dbm",
    "lte_snr_db",

    "nr5g_rsrp_dbm",
    "nr5g_rsrq_db",
    "nr5g_snr_db",

    "ipv4_address",
    "gateway",
    "dns1",
    "dns2",
    "mtu",
    
    "utm_ping_status",
    "utm_latency_ms",
]


def init_csv():
    """Create a fresh CSV file for this execution only."""
    with open(config.CSV_FILE, "w", newline="", encoding="utf-8") as f:
        csv.DictWriter(f, fieldnames=CSV_FIELDS).writeheader()


def _csv_path_for_part(part):
    if part <= 1:
        return config.CSV_FILE
    return config.CSV_FILE.with_name(
        config.CSV_FILE.stem + f"_part{part}" + config.CSV_FILE.suffix
    )


def _append_csv_row(record):
    """Append one row and rotate before exceeding the configured row limit."""

    limit = max(1, int(config.CSV_MAX_ROWS_PER_FILE))

    part = getattr(_append_csv_row, "part", 1)
    rows = getattr(_append_csv_row, "rows", 0)

    path = _csv_path_for_part(part)

    try:
        file_exists = os.path.exists(path)
        file_empty = file_exists and os.path.getsize(path) == 0

        with open(
            path,
            "a",
            newline="",
            encoding="utf-8"
        ) as f:

            writer = csv.DictWriter(
                f,
                fieldnames=CSV_FIELDS,
                extrasaction="ignore"
            )

            # Always guarantee a header.
            if not file_exists or file_empty:
                writer.writeheader()

            writer.writerow(record)

        rows += 1

        # Rotate AFTER reaching the limit.
        if rows >= limit:
            part += 1
            rows = 0

        _append_csv_row.part = part
        _append_csv_row.rows = rows

    except Exception as e:
        print(f"[CSV] Write error: {e}", flush=True)


def append_timestamp_only_row(sample_time=None):
    """Record only the timestamp when QMI data is unavailable/recovering."""
    ts = (sample_time or datetime.now(timezone.utc)).astimezone().isoformat(timespec="milliseconds")
    record = {field: "" for field in CSV_FIELDS}
    record["timestamp"] = ts
    _append_csv_row(record)


def run_system(command):
    try:
        result = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=5
        )
        return result.returncode, result.stdout.strip()
    except Exception:
        return 1, ""


def first_match(patterns, text):
    for pattern in patterns:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            return m.group(1)
    return ""


def clean_value(value):
    if value is None:
        return ""
    return value.strip().strip("'").strip('"')


def parse_signal_info(output):
    data = {
        "lte_rssi_dbm": "",
        "lte_rsrq_db": "",
        "lte_rsrp_dbm": "",
        "lte_snr_db": "",
        "nr5g_rsrp_dbm": "",
        "nr5g_rsrq_db": "",
        "nr5g_snr_db": "",
    }

    # qmicli commonly returns values such as:
    # LTE:
    #   RSSI: '-84 dBm'
    #   RSRQ: '-18 dB'
    #   RSRP: '-120 dBm'
    #   SNR: '1.4 dB'
    #
    # The radio heading may differ between libqmi versions, so first
    # split the LTE/NR blocks when possible and otherwise use labels.

    lte_block = output
    nr_block = ""

    m = re.search(
        r"(?:LTE|LTE\s+signal).*?(?=(?:NR5G|5G|WCDMA|GSM|CDMA)|$)",
        output,
        re.IGNORECASE | re.DOTALL
    )
    if m:
        lte_block = m.group(0)

    m = re.search(
        r"(?:NR5G|5G).*",
        output,
        re.IGNORECASE | re.DOTALL
    )
    if m:
        nr_block = m.group(0)

    def get_metric(block, name):
        m = re.search(
            rf"{name}\s*:\s*'([^']+)'",
            block,
            re.IGNORECASE
        )
        return clean_value(m.group(1)) if m else ""

    data["lte_rssi_dbm"] = get_metric(lte_block, "RSSI")
    data["lte_rsrq_db"] = get_metric(lte_block, "RSRQ")
    data["lte_rsrp_dbm"] = get_metric(lte_block, "RSRP")
    data["lte_snr_db"] = get_metric(lte_block, "SNR")

    if nr_block:
        data["nr5g_rsrp_dbm"] = get_metric(nr_block, "RSRP")
        data["nr5g_rsrq_db"] = get_metric(nr_block, "RSRQ")
        data["nr5g_snr_db"] = get_metric(nr_block, "SNR")

    # Fallback: if the modem/libqmi output has no radio headings,
    # retain the first values under the generic labels as LTE values.
    if not any(data.values()):
        data["lte_rssi_dbm"] = first_match(
            [r"RSSI:\s*'([^']+)'"], output
        )
        data["lte_rsrq_db"] = first_match(
            [r"RSRQ:\s*'([^']+)'"], output
        )
        data["lte_rsrp_dbm"] = first_match(
            [r"RSRP:\s*'([^']+)'"], output
        )
        data["lte_snr_db"] = first_match(
            [r"SNR:\s*'([^']+)'"], output
        )

    return data


def parse_serving_system(output):
    data = {
        "registration_state": "",
        "radio_interfaces": "",
        "mcc": "",
        "mnc": "",
    }

    # Examples vary by libqmi version:
    # Registration state: 'registered'
    # MCC: '404'
    # MNC: '45'
    # Radio interfaces: 'lte'
    data["registration_state"] = first_match(
        [
            r"Registration state:\s*'([^']+)'",
            r"Registration state:\s*([^\n]+)",
        ],
        output
    )

    radio = re.findall(
        r"Radio interface:\s*'([^']+)'",
        output,
        re.IGNORECASE
    )
    if not radio:
        radio = re.findall(
            r"Radio interfaces?:\s*'([^']+)'",
            output,
            re.IGNORECASE
        )
    data["radio_interfaces"] = ",".join(dict.fromkeys(radio))

    data["mcc"] = first_match(
        [r"\bMCC:\s*'([^']+)'", r"\bMCC:\s*(\d+)"],
        output
    )
    data["mnc"] = first_match(
        [r"\bMNC:\s*'([^']+)'", r"\bMNC:\s*(\d+)"],
        output
    )

    return data


def parse_cell_location(output):
    data = {"cell_id": "", "pci": ""}

    # Common libqmi representations include:
    # Cell ID: '12345'
    # Physical Cell ID: '166'
    # PCI: '166'
    data["cell_id"] = first_match(
        [
            r"Cell ID:\s*'([^']+)'",
            r"Cell ID:\s*(\d+)",
            r"Cell ID:\s*0x([0-9a-fA-F]+)",
        ],
        output
    )

    data["pci"] = first_match(
        [
            r"Physical Cell ID:\s*'([^']+)'",
            r"Physical Cell ID:\s*(\d+)",
            r"\bPCI:\s*'([^']+)'",
            r"\bPCI:\s*(\d+)",
        ],
        output
    )

    return data


def parse_packet_status(output):
    if "connected" in output.lower():
        return "CONNECTED"
    if "disconnected" in output.lower():
        return "DISCONNECTED"
    return ""


def get_wan_interface():
    """
    Detect the likely cellular WAN interface.

    Prefer interfaces with a cellular-looking name. If there is no such
    interface, inspect the default route. This avoids hard-coding wwan0.
    """
    rc, output = run_system(["ip", "-o", "link", "show"])
    if rc == 0:
        names = []
        for line in output.splitlines():
            m = re.match(r"\d+:\s+([^:]+):", line)
            if m:
                name = m.group(1)
                if (
                    name.startswith("wwan") or
                    name.startswith("wwx") or
                    name.startswith("rmnet") or
                    name.startswith("usb")
                ):
                    names.append(name)

        if names:
            # Prefer an interface that has an IPv4 address.
            for name in names:
                rc2, out2 = run_system(
                    ["ip", "-4", "addr", "show", "dev", name]
                )
                if rc2 == 0 and "inet " in out2:
                    return name
            return names[0]

    # Fallback to default route interface.
    rc, output = run_system(["ip", "route", "show", "default"])
    if rc == 0:
        m = re.search(r"\bdev\s+(\S+)", output)
        if m:
            return m.group(1)

    return ""


def get_network_config(wan_interface):
    data = {
        "ipv4_address": "",
        "gateway": "",
        "dns1": "",
        "dns2": "",
        "mtu": "",
    }

    if not wan_interface:
        return data

    rc, output = run_system(
        ["ip", "-4", "addr", "show", "dev", wan_interface]
    )
    if rc == 0:
        m = re.search(r"\binet\s+(\d+\.\d+\.\d+\.\d+)/\d+", output)
        if m:
            data["ipv4_address"] = m.group(1)

    rc, output = run_system(
        ["ip", "route", "show", "dev", wan_interface]
    )
    if rc == 0:
        m = re.search(
            r"(?:default\s+via\s+)(\d+\.\d+\.\d+\.\d+)",
            output
        )
        if m:
            data["gateway"] = m.group(1)

    rc, output = run_system(
        ["ip", "link", "show", "dev", wan_interface]
    )
    if rc == 0:
        m = re.search(r"\bmtu\s+(\d+)", output)
        if m:
            data["mtu"] = m.group(1)

    # DNS: first try resolvectl for the detected WAN interface.
    rc, output = run_system(["resolvectl", "dns", wan_interface])
    if rc == 0:
        ips = re.findall(
            r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
            output
        )
        if ips:
            data["dns1"] = ips[0]
            if len(ips) > 1:
                data["dns2"] = ips[1]

    # Fallback: /etc/resolv.conf
    if not data["dns1"]:
        try:
            text = open("/etc/resolv.conf", encoding="utf-8").read()
            ips = re.findall(
                r"^\s*nameserver\s+((?:\d{1,3}\.){3}\d{1,3})",
                text,
                re.MULTILINE
            )
            if ips:
                data["dns1"] = ips[0]
                if len(ips) > 1:
                    data["dns2"] = ips[1]
        except Exception:
            pass

    return data


def get_qmi_network_info(logger):
    """
    Collect the QMI network/session information required for the CSV.
    Full command/response details are written by qmi() to the session log.
    """
    data = {
        "packet_session": "",
        "registration_state": "",
        "cs_attach_state": "",
        "ps_attach_state": "",
        "radio_interfaces": "",
        "mcc": "",
        "mnc": "",
        "cell_id": "",
        "pci": "",
    }

    rc, output = qmi(
        "--wds-get-packet-service-status",
        logger
    )
    if rc == 0:
        data["packet_session"] = parse_packet_status(output)

    rc, serving_output = qmi(
        "--nas-get-serving-system",
        logger
    )
    if rc == 0:
        serving = parse_serving_system(serving_output)
        data.update(serving)

        # Some modem/libqmi combinations expose attach state here.
        data["cs_attach_state"] = first_match(
            [
                r"CS attach state:\s*'([^']+)'",
                r"CS attach state:\s*([^\n]+)",
                r"CS attachment state:\s*'([^']+)'",
            ],
            serving_output
        )

        data["ps_attach_state"] = first_match(
            [
                r"PS attach state:\s*'([^']+)'",
                r"PS attach state:\s*([^\n]+)",
                r"PS attachment state:\s*'([^']+)'",
            ],
            serving_output
        )

    # This is supported by the qmicli build discussed in this project.
    rc, cell_output = qmi(
        "--nas-get-cell-location-info",
        logger
    )
    if rc == 0:
        cell = parse_cell_location(cell_output)
        data.update(cell)

    return data
    
def prepare_mqtt_data(d):
    telemetry = {k: d[k] for k in [
        "timestamp",
        "mav_timestamp",
        "mavlink_age_ms",
        "fc_time_boot_ms",
        "gps_lat",
        "gps_lon",
        "altitude_msl_m",
        "relative_altitude_m",
        "ground_speed_mps",
        "heading_deg",
        "gps_fix_type",
        "satellites_visible",
        "fc_armed"
    ]}

    signal = {k: d[k] for k in [
        "timestamp",
        "mcc",
        "mnc",
        "cell_id",
        "pci",
        "radio_interfaces",
        "lte_rssi_dbm",
        "lte_rsrq_db",
        "lte_rsrp_dbm",
        "lte_snr_db"
    ]}

    network = {k: d[k] for k in [
        "timestamp",
        "qmi_device",
        "wan_interface",
        "apn",
        "packet_session",
        "registration_state",
        "ipv4_address",
        "gateway",
        "dns1",
        "dns2",
        "mtu",
        "utm_ping_status",
        "utm_latency_ms"
    ]}

    return {
        "telemetry": telemetry,
        "signal": signal,
        "network": network
    }
    
def read_signal(logger, mav_data, sample_time=None):
    # Add new QMI commands in get_qmi_network_info() below.
    # Keep each command + parser together there so future additions are easy.
    # sample_time is the timestamp captured immediately before this QMI
    # sample. It is kept separate from the MAVLink receive timestamp.
    qmi_sample_time = sample_time or datetime.now(timezone.utc)

    # 1. RF signal
    rc, signal_output = qmi(
        "--nas-get-signal-info",
        logger
    )
    if rc != 0:
        # QMI signal data temporarily unavailable.
        # Do NOT stop the complete telemetry record.
        signal = {
            "lte_rssi_dbm": "",
            "lte_rsrq_db": "",
            "lte_rsrp_dbm": "",
            "lte_snr_db": "",
            "nr5g_rsrp_dbm": "",
            "nr5g_rsrq_db": "",
            "nr5g_snr_db": "",
        }

        if logger:
            logger.write(
                "QMI SIGNAL",
                "--nas-get-signal-info",
                signal_output,
                "FAILED"
            )
    else:
        signal = parse_signal_info(signal_output)

    # 2. Packet/network information
    network = get_qmi_network_info(logger)


    # UTM ping is handled by utm.py in a background thread.
    packet_session = network.get("packet_session", "").strip().lower()
    if packet_session == "connected":
        start_utm_ping(logger)
        utm_status, utm_latency = get_utm_result()
    else:
        utm_status = "NOT_TESTED"
        utm_latency = ""


    # 3. Linux WAN/IP information
    wan_interface = get_wan_interface()
    net_config = get_network_config(wan_interface)

    # 4. Combine the latest MAVLink snapshot with the QMI sample.
    record = {field: "" for field in CSV_FIELDS}

    record.update(mav_data or {})
    record.update(signal)
    record.update(network)
    record.update(net_config)

    # All CSV timestamps are local system time with timezone offset.
    # MAVLink timestamps are generated at the exact FC-message receive event.
    # qmi_timestamp is the timestamp of this QMI collection cycle.
    record["timestamp"] = datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds") # or qmi_sample_time.astimezone().isoformat(timespec="milliseconds")
    record["qmi_timestamp"] = qmi_sample_time.astimezone().isoformat(timespec="milliseconds")
    record["qmi_device"] = config.QMI_DEVICE or ""
    record["wan_interface"] = wan_interface
    record["apn"] = config.APN
    record["utm_ping_status"] = utm_status
    record["utm_latency_ms"] = utm_latency

    # CSV logging only when FC is armed
    fc_armed = record.get("fc_armed")

    is_armed = fc_armed in (True, 1, "1", "true", "True", "ARMED", "armed")
    
    if is_armed:
        _append_csv_row(record)

        if not getattr(read_signal, "_csv_logged_message", False):
            print("[CSV] Logged in CSV", flush=True)
            read_signal._csv_logged_message = True

        # Reset disarmed message flag
        read_signal._csv_disarmed_message = False

    else:
        # Print only once while disarmed
        if not getattr(read_signal, "_csv_disarmed_message", False):
            print("[FC] Disarmed - CSV not generating", flush=True)
            read_signal._csv_disarmed_message = True

        # Reset CSV message so it prints again on next arm
        read_signal._csv_logged_message = False

    return record
