import glob
import os
import subprocess
import shlex
import threading
import time
import signal
import config

# Internal QMI safety timing.
QMI_COMMAND_TIMEOUT = 2.0
QMI_SESSION_TIMEOUT = 10.0
QMI_DEVICE_TIMEOUT = 2.0
QMI_LOCK_TIMEOUT = 0.25
QMI_RECOVERY_BACKOFF = 1.0

# Number of times a transient QMI transport failure is retried
QMI_COMMAND_RETRIES = 2

_QMI_LOCK = threading.RLock()
_LAST_DIAG = 0.0


def run(command, timeout=10):
    """
    Safe subprocess execution.

    Guarantees:
      - never raises subprocess exceptions to caller
      - enforces timeout
      - terminates only the process started here
      - captures stdout + stderr
      - returns (returncode, output)
    """

    process = None

    try:
        process = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True
        )

        try:
            output, _ = process.communicate(timeout=timeout)

            return (
                process.returncode,
                (output or "").strip()
            )

        except subprocess.TimeoutExpired:

            # First try graceful termination of the process group.
            try:
                os.killpg(
                    process.pid,
                    signal.SIGTERM
                )
            except Exception:
                pass

            # Give it a short chance to terminate.
            try:
                output, _ = process.communicate(timeout=0.5)

            except subprocess.TimeoutExpired:

                # Force kill only this process group.
                try:
                    os.killpg(
                        process.pid,
                        signal.SIGKILL
                    )
                except Exception:
                    pass

                try:
                    output, _ = process.communicate(timeout=0.5)
                except Exception:
                    output = ""

            return 124, (
                "Command timed out after "
                f"{timeout:.1f}s\n"
                f"{(output or '').strip()}"
            ).strip()

    except FileNotFoundError:
        return 127, f"Command not found: {command[0]}"

    except PermissionError:
        return 126, f"Permission denied: {command[0]}"

    except OSError as e:
        return 1, f"OS error executing command: {e}"

    except Exception as e:
        return 1, f"Unexpected command execution error: {e}"

    finally:
        # Safety cleanup.
        if process is not None:
            try:
                if process.poll() is None:
                    os.killpg(
                        process.pid,
                        signal.SIGKILL
                    )
            except Exception:
                pass


def _is_qmi_transport_error(output):
    """
    Errors indicating that the QMI control/client transport
    may be temporarily unusable.
    """

    text = (output or "").lower()

    return any(x in text for x in (
        "endpoint hangup",
        "connection reset by peer",
        "connection broken",
        "couldn't open the qmidevice",
        "couldn't open the qmi device",
        "couldn't spawn the qmi-proxy",
        "cid allocation failed",
        "service mismatch",
    ))


def _is_missing_device_error(output):
    text = (output or "").lower()

    return any(x in text for x in (
        "no such file or directory",
        "couldn't create qmi device",
        "couldn't query file info",
        "endpoint hangup",
        "connection broken",
        "connection reset by peer",
        "couldn't open the qmidevice",
        "couldn't open the qmi device",
        "couldn't spawn the qmi-proxy",
    ))


def _diagnose(logger, reason):
    global _LAST_DIAG

    if not logger:
        return

    now = time.monotonic()

    cooldown = float(
        getattr(
            config,
            "SYSTEM_DIAGNOSTIC_COOLDOWN",
            30.0
        )
    )

    if now - _LAST_DIAG < cooldown:
        return

    try:
        logger.system_diagnostics(reason)
    except Exception:
        pass

    _LAST_DIAG = now


def _get_qmi_devices():
    """
    Return currently available QMI control devices.

    Current configured device gets priority.
    """

    devices = sorted(
        glob.glob("/dev/cdc-wdm*")
    )

    current = config.QMI_DEVICE

    ordered = (
        ([current] if current in devices else [])
        +
        [d for d in devices if d != current]
    )

    return ordered


def find_qmi_device(logger=None):
    """
    Safely discover a usable QMI control device.

    DMS is checked first for modem health.
    WDS is used as fallback because WDS is required
    for the data session.
    """

    with _QMI_LOCK:

        devices = _get_qmi_devices()

        if not devices:

            if logger:
                logger.write(
                    "QMI DEVICE DISCOVERY",
                    "",
                    "No /dev/cdc-wdm* device found",
                    "FAILED"
                )

            return None

        # --------------------------------------------------
        # DMS CHECK
        # --------------------------------------------------

        for device in devices:

            command = [
                "qmicli",
                "-p",
                "-d",
                device,
                "--dms-get-operating-mode"
            ]

            rc, output = run(
                command,
                timeout=QMI_DEVICE_TIMEOUT
            )

            if logger:
                logger.write(
                    "QMI DEVICE CHECK",
                    " ".join(command),
                    output,
                    "SUCCESS" if rc == 0 else "FAILED"
                )

            if (
                rc == 0
                and "online" in output.lower()
            ):
                changed = (
                    config.QMI_DEVICE != device
                )

                config.QMI_DEVICE = device

                if changed and logger:
                    logger.write(
                        "QMI DEVICE REDISCOVERED",
                        "",
                        f"Selected usable QMI control device: {device}",
                        "RECOVERY"
                    )

                return device

        # --------------------------------------------------
        # WDS FALLBACK
        # --------------------------------------------------

        for device in _get_qmi_devices():

            command = [
                "qmicli",
                "-p",
                "-d",
                device,
                "--wds-get-packet-service-status"
            ]

            rc, output = run(
                command,
                timeout=QMI_DEVICE_TIMEOUT
            )

            if logger:
                logger.write(
                    "QMI WDS DEVICE CHECK",
                    " ".join(command),
                    output,
                    "SUCCESS" if rc == 0 else "FAILED"
                )

            if rc == 0:

                changed = (
                    config.QMI_DEVICE != device
                )

                config.QMI_DEVICE = device

                if changed and logger:
                    logger.write(
                        "QMI DEVICE REDISCOVERED",
                        "",
                        f"Selected usable QMI control device: {device}",
                        "RECOVERY"
                    )

                return device

        return None


def qmi(
    command,
    logger=None,
    timeout=QMI_COMMAND_TIMEOUT,
    rediscover=True
):
    """
    Serialized and safe QMI command execution.

    Handles:
      - missing QMI device
      - endpoint hangup
      - connection reset
      - qmi-proxy failure
      - service mismatch
      - CID allocation failure
      - command timeout
    """

    with _QMI_LOCK:

        device = config.QMI_DEVICE

        # --------------------------------------------------
        # DEVICE DISCOVERY
        # --------------------------------------------------

        if (
            not device
            or not os.path.exists(device)
        ):

            if rediscover:
                device = find_qmi_device(logger)

            if not device:

                output = (
                    "No usable /dev/cdc-wdm* "
                    "QMI device detected"
                )

                if logger:
                    logger.write(
                        "QMI COMMAND",
                        command,
                        output,
                        "FAILED"
                    )

                return 1, output

        command_args = shlex.split(command)

        full = [
            "qmicli",
            "-p",
            "-d",
            device
        ] + command_args

        # --------------------------------------------------
        # COMMAND + LIMITED RETRIES
        # --------------------------------------------------

        last_rc = 1
        last_output = ""

        for attempt in range(
            QMI_COMMAND_RETRIES + 1
        ):

            rc, output = run(
                full,
                timeout
            )

            last_rc = rc
            last_output = output

            if logger:
                logger.write(
                    "QMI COMMAND",
                    " ".join(full),
                    output,
                    "SUCCESS" if rc == 0 else "FAILED"
                )

            # SUCCESS
            if rc == 0:
                return rc, output

            # TIMEOUT
            if rc == 124:

                _diagnose(
                    logger,
                    "QMI command timeout"
                )

                return rc, output

            # --------------------------------------------------
            # TRANSPORT ERROR
            # --------------------------------------------------

            if _is_qmi_transport_error(output):

                _diagnose(
                    logger,
                    "QMI transport/client failure: "
                    + (output or "unknown")
                )

                if attempt < QMI_COMMAND_RETRIES:

                    if logger:
                        logger.write(
                            "QMI COMMAND RECOVERY",
                            " ".join(full),
                            (
                                "Transient QMI transport failure; "
                                f"retry {attempt + 1}/"
                                f"{QMI_COMMAND_RETRIES}"
                            ),
                            "RECOVERY"
                        )

                    time.sleep(
                        QMI_RECOVERY_BACKOFF
                    )

                    # Re-discover before retry.
                    if rediscover:

                        new_device = (
                            find_qmi_device(logger)
                        )

                        if new_device:
                            device = new_device

                            full = [
                                "qmicli",
                                "-p",
                                "-d",
                                device
                            ] + command_args

                            continue

                break

            # Non-transport failure
            break

        return last_rc, last_output
