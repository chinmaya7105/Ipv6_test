#!/usr/bin/env python3
"""
IPv6 coexistence manager for the combined LTE/5G QMI service.

IPv4 ownership/recovery remains in wan.py. This module only makes sure the
dedicated IPv6 QMI session and Linux IPv6 routing are present. The actual
IPv6 QMI sequence remains in the validated shell script supplied with the
project.
"""
import os
import subprocess
import time
from pathlib import Path

SCRIPT = Path(__file__).resolve().parent / "qmi_ipv6_wan_jetson_ipv4_ipv6_coexist_final.sh"
PING6 = "2001:4860:4860::8888"


def _run(cmd, timeout=15):
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=timeout)
        return p.returncode, (p.stdout or "").strip()
    except Exception as exc:
        return 1, str(exc)


def _log(logger, event, detail, status="INFO"):
    if logger:
        try:
            logger.write(event, "IPv4/IPv6 combined WAN", detail, status)
        except Exception:
            pass


def ipv6_local_healthy(interface):
    """Check address + default route on the supplied dynamically detected WWAN."""
    rc1, addr = _run(["ip", "-6", "-o", "addr", "show", "dev", interface, "scope", "global"])
    if rc1 != 0 or not addr.strip():
        return False, "No global IPv6 address"

    rc2, route = _run(["ip", "-6", "route", "show", "default", "dev", interface])
    if rc2 != 0 or not route.strip():
        return False, "No IPv6 default route"

    return True, f"IPv6 address and default route present on {interface}"


def ipv6_internet_healthy(interface):
    """Use the cellular interface explicitly; no dependency on the system default route."""
    rc, out = _run(["ping", "-6", "-I", interface, "-c", "2", "-W", "3", PING6], timeout=10)
    return rc == 0, out


def ensure_ipv6(logger, qmi_device, interface, apn):
    """Run the validated IPv6 setup only when IPv6 is not already healthy."""
    if not qmi_device or not interface:
        return False, "IPv4 WAN has not supplied a QMI device/interface yet"

    if not SCRIPT.exists():
        return False, f"IPv6 setup script not found: {SCRIPT}"

    local_ok, detail = ipv6_local_healthy(interface)
    if local_ok:
        internet_ok, ping_detail = ipv6_internet_healthy(interface)
        if internet_ok:
            _log(logger, "IPv6 WAN", f"Already healthy: {detail}", "SUCCESS")
            return True, "IPv6 already healthy"
        _log(logger, "IPv6 WAN", f"Address/route present but IPv6 Internet test failed: {ping_detail}", "WARNING")

    env = os.environ.copy()
    env["QMI_WDM"] = qmi_device
    env["QMI_IFACE"] = interface
    env["QMI_APN"] = apn

    _log(logger, "IPv6 WAN SETUP",
         f"Starting IPv6 coexistence setup: QMI_WDM={qmi_device}, QMI_IFACE={interface}, APN={apn}",
         "RECOVERY")

    try:
        p = subprocess.run(
            ["bash", str(SCRIPT), apn],
            cwd=str(SCRIPT.parent),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=120,
        )
        output = p.stdout or ""
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or "") if isinstance(exc.stdout, str) else ""
        _log(logger, "IPv6 WAN SETUP", output + "\nIPv6 setup timed out", "FAILED")
        return False, "IPv6 setup timed out"
    except Exception as exc:
        _log(logger, "IPv6 WAN SETUP", str(exc), "FAILED")
        return False, str(exc)

    if output:
        # Keep service logs useful without flooding the application console.
        for line in output.splitlines():
            if line.strip():
                _log(logger, "IPv6 QMI", line, "INFO")

    if p.returncode != 0:
        _log(logger, "IPv6 WAN SETUP", f"IPv6 script exited with code {p.returncode}", "FAILED")
        return False, f"IPv6 setup failed rc={p.returncode}"

    local_ok, local_detail = ipv6_local_healthy(interface)
    if not local_ok:
        _log(logger, "IPv6 WAN VERIFY", local_detail, "FAILED")
        return False, local_detail

    internet_ok, ping_detail = ipv6_internet_healthy(interface)
    if not internet_ok:
        _log(logger, "IPv6 WAN VERIFY", ping_detail, "WARNING")
        return False, "IPv6 route exists but Internet verification failed"

    _log(logger, "IPv6 WAN VERIFY", f"IPv6 Internet healthy on {interface}", "SUCCESS")
    return True, "IPv6 WAN healthy"


def watchdog_loop(logger, stop_event, get_wan_state, apn, interval=10):
    """
    IPv6 watchdog. It follows the IPv4 service's currently detected QMI device
    and WWAN interface, so modem re-enumeration does not require fixed names.
    """
    consecutive_failures = 0

    while not stop_event.wait(interval):
        try:
            state = get_wan_state() or {}
            qmi_device = state.get("qmi_device", "")
            interface = state.get("interface", "")

            if not qmi_device or not interface:
                continue

            ok, detail = ensure_ipv6(logger, qmi_device, interface, apn)
            if ok:
                consecutive_failures = 0
            else:
                consecutive_failures += 1
                _log(logger, "IPv6 WATCHDOG",
                     f"Check/setup failed ({consecutive_failures}): {detail}",
                     "WARNING")
        except Exception as exc:
            consecutive_failures += 1
            _log(logger, "IPv6 WATCHDOG", str(exc), "FAILED")
