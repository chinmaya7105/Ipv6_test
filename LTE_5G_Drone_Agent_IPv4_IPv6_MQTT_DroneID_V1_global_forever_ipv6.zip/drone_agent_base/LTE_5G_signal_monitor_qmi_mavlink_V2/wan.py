import os
import ipaddress
import re
import time

import config
from qmi import qmi, find_qmi_device


def run_cmd(command, timeout=10):
    import subprocess
    try:
        r = subprocess.run(
            command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, timeout=timeout
        )
        return r.returncode, r.stdout.strip()
    except subprocess.TimeoutExpired:
        return 124, "Command timed out"
    except Exception as e:
        return 1, str(e)


def mask_to_prefix(mask):
    try:
        return ipaddress.IPv4Network(f"0.0.0.0/{mask}").prefixlen
    except Exception:
        return None


def get_interface(logger=None):
    rc, output = qmi("--get-wwan-iface", logger)
    if rc == 0:
        name = output.strip().splitlines()[-1].strip()
        if re.fullmatch(r"[A-Za-z0-9_.:-]+", name):
            return name
    return ""


def get_current_settings(logger=None):
    data = {
        "ip": "", "mask": "", "gateway": "",
        "dns1": "", "dns2": "", "mtu": "", "prefix": None
    }

    rc, output = qmi("--wds-get-current-settings", logger)
    if rc != 0:
        return data, False, output

    patterns = {
        "ip": r"IPv4 address:\s*([0-9.]+)",
        "mask": r"IPv4 subnet mask:\s*([0-9.]+)",
        "gateway": r"IPv4 gateway address:\s*([0-9.]+)",
        "dns1": r"IPv4 primary DNS:\s*([0-9.]+)",
        "dns2": r"IPv4 secondary DNS:\s*([0-9.]+)",
        "mtu": r"MTU:\s*(\d+)",
    }
    for key, pattern in patterns.items():
        m = re.search(pattern, output, re.IGNORECASE)
        if m:
            data[key] = m.group(1)

    data["prefix"] = mask_to_prefix(data["mask"]) if data["mask"] else None
    ok = bool(data["ip"] and data["gateway"] and data["prefix"] is not None)
    return data, ok, output


def interface_ipv4(interface):
    rc, output = run_cmd(["ip", "-4", "addr", "show", "dev", interface])
    if rc != 0:
        return ""
    m = re.search(r"\binet\s+([0-9.]+)/\d+", output)
    return m.group(1) if m else ""


def route_for_interface(interface):
    rc, output = run_cmd(["ip", "route", "show", "default", "dev", interface])
    return output if rc == 0 else ""


def configure_interface(interface, settings, logger=None):
    """Modify Linux WAN only after QMI has been proven healthy."""
    ip = settings["ip"]
    gateway = settings["gateway"]
    prefix = settings["prefix"]
    mtu = settings.get("mtu")

    if not interface or not ip or not gateway or prefix is None:
        return False, "Missing dynamic QMI WAN settings"

    commands = [
        ["ip", "link", "set", "dev", interface, "up"],
        ["ip", "-4", "addr", "flush", "dev", interface, "scope", "global"],
        ["ip", "addr", "replace", f"{ip}/{prefix}", "dev", interface],
    ]

    if mtu and mtu.isdigit():
        commands.append(["ip", "link", "set", "dev", interface, "mtu", mtu])

    network = ipaddress.IPv4Interface(f"{ip}/{prefix}").network
    commands.append([
        "ip", "route", "replace", str(network), "dev", interface, "src", ip
    ])

    # Remove only stale cellular defaults on THIS detected interface.
    commands.append(["ip", "route", "del", "default", "dev", interface])

    commands.append([
        "ip", "route", "replace", "default",
        "via", gateway, "dev", interface, "src", ip, "metric", "10"
    ])

    for command in commands:
        rc, output = run_cmd(command)
        if logger:
            logger.write(
                "WAN COMMAND", " ".join(command), output,
                "SUCCESS" if rc == 0 else "FAILED"
            )

        optional_delete = (
            command[:5] == ["ip", "route", "del", "default", "dev"]
        )
        if rc != 0 and not optional_delete:
            return False, output

    return True, (
        f"interface={interface}, ip={ip}/{prefix}, gateway={gateway}"
    )


def verify_wan(interface, settings, logger=None):
    """Verify local WAN configuration only. No gateway ping."""
    expected_ip = settings.get("ip", "")
    expected_gw = settings.get("gateway", "")
    expected_prefix = settings.get("prefix")

    if not interface or not expected_ip or not expected_gw or expected_prefix is None:
        return False, "Incomplete dynamic QMI WAN settings"

    rc, link = run_cmd(["ip", "link", "show", "dev", interface])
    if rc != 0:
        return False, f"Interface {interface} does not exist"

    actual_ip = interface_ipv4(interface)
    if actual_ip != expected_ip:
        return False, (
            f"IPv4 mismatch: expected {expected_ip}, actual {actual_ip}"
        )

    route = route_for_interface(interface)
    if not re.search(rf"default\s+via\s+{re.escape(expected_gw)}\b", route):
        return False, (
            f"Default route mismatch: expected gateway {expected_gw}, "
            f"route={route}"
        )

    return True, (
        f"WAN healthy: interface={interface}, IP={expected_ip}/{expected_prefix}, "
        f"gateway={expected_gw}, route={route}"
    )


def packet_connected(logger=None):
    rc, output = qmi("--wds-get-packet-service-status", logger)

    if rc != 0:
        return False, output

    # IMPORTANT: "disconnected" contains the substring "connected".
    # Never use `"connected" in output` for QMI WDS state.
    match = re.search(
        r"Connection status:\s*[\'\"]([^\'\"]+)[\'\"]",
        output,
        re.IGNORECASE,
    )
    status = match.group(1).strip().lower() if match else ""

    return status == "connected", output


def get_wan_session_mode():
    """Return configured WAN session owner."""
    return str(getattr(config, "WAN_SESSION_MODE", "QMI")).strip().upper()


def modemmanager_is_active(logger=None):
    """Check ModemManager state without repeating the same log every watchdog cycle."""
    rc, output = run_cmd(["systemctl", "is-active", "ModemManager"], timeout=15)
    active = output.strip() == "active"
    previous = getattr(modemmanager_is_active, "_last_state", None)
    if logger and active != previous:
        logger.write(
            "MODEMMANAGER STATUS",
            "systemctl is-active ModemManager",
            output,
            "SUCCESS" if active else "WARNING",
        )
        modemmanager_is_active._last_state = active
    return active


def start_modemmanager(logger=None):
    rc, output = run_cmd(
        ["systemctl", "enable", "--now", "ModemManager"], timeout=30
    )
    if logger:
        logger.write(
            "MODEMMANAGER START",
            "systemctl enable --now ModemManager",
            output,
            "SUCCESS" if rc == 0 else "FAILED",
        )
    if rc == 0:
        modemmanager_is_active._last_state = True
    return rc == 0, output


def stop_modemmanager(logger=None):
    rc, output = run_cmd(["systemctl", "stop", "ModemManager"], timeout=30)
    if logger:
        logger.write(
            "MODEMMANAGER STOP",
            "systemctl stop ModemManager",
            output,
            "SUCCESS" if rc == 0 else "FAILED",
        )
    if rc == 0:
        modemmanager_is_active._last_state = False
        time.sleep(float(getattr(config, "QMI_MM_HANDOVER_DELAY", 2.0)))
    return rc == 0, output


def ensure_wwan_raw_ip(interface, logger=None):
    """Check/set the Linux qmi_wwan raw_ip switch for the dynamic interface."""
    path = f"/sys/class/net/{interface}/qmi/raw_ip"
    if not os.path.exists(path):
        return False, f"RAW-IP sysfs path not available: {path}"
    try:
        with open(path, "r", encoding="utf-8") as f:
            current = f.read().strip().upper()

        if logger:
            logger.write(
                "QMI RAW-IP CHECK",
                f"cat {path}",
                current,
                "SUCCESS" if current == "Y" else "WARNING",
            )

        if current == "Y":
            return True, "raw_ip=Y"
        if current != "N":
            return False, f"Unexpected raw_ip value: {current}"

        # raw_ip can only be changed while the interface is administratively
        # DOWN. Writing it while the link is up fails with EBUSY
        # ("Device or resource busy"). The interface is brought back up by
        # the caller's bring_wwan_up() afterward.
        run_cmd(["ip", "link", "set", "dev", interface, "down"])

        with open(path, "w", encoding="utf-8") as f:
            f.write("Y")

        with open(path, "r", encoding="utf-8") as f:
            verify = f.read().strip().upper()

        if logger:
            logger.write(
                "QMI RAW-IP SET",
                f"echo Y > {path}",
                verify,
                "SUCCESS" if verify == "Y" else "FAILED",
            )
        return verify == "Y", f"raw_ip={verify}"
    except Exception as e:
        if logger:
            logger.write("QMI RAW-IP", path, str(e), "FAILED")
        return False, str(e)


def bring_wwan_up(interface, logger=None):
    """Bring the dynamically detected WWAN interface UP."""
    rc, output = run_cmd(["ip", "link", "set", "dev", interface, "up"])
    if logger:
        logger.write(
            "WAN INTERFACE",
            f"ip link set dev {interface} up",
            output,
            "SUCCESS" if rc == 0 else "FAILED",
        )
    return rc == 0, output


def modemmanager_wan_check(logger=None):
    """Validate MM-owned WAN without manually changing Linux IP/routes."""
    if not modemmanager_is_active(logger):
        ok, output = start_modemmanager(logger)
        if not ok:
            return False, "", {}, output
        time.sleep(float(getattr(config, "MODEMMANAGER_STARTUP_DELAY", 5.0)))

    device = find_qmi_device(logger)
    if not device:
        return False, "", {}, "No usable QMI control device"

    rc, modem = qmi("--dms-get-operating-mode", logger)
    if rc != 0 or "online" not in modem.lower():
        return False, "", {}, "Modem is not ONLINE"

    rc, sim = qmi("--uim-get-card-status", logger)
    if rc != 0 or "application state: 'ready'" not in sim.lower():
        return False, "", {}, "SIM is not READY"

    rc, registration = qmi("--nas-get-serving-system", logger)
    reg_text = registration.lower()
    if rc != 0 or not any(
        x in reg_text for x in ("registered", "home", "roaming", "current network")
    ):
        return False, "", {}, "Network is not registered"

    connected, status = packet_connected(logger)
    if not connected:
        return False, "", {}, f"Packet session is not CONNECTED: {status}"

    interface = get_interface(logger)
    if not interface:
        return False, "", {}, "No WWAN interface reported by QMI"

    settings, valid, raw = get_current_settings(logger)
    if not valid:
        return False, interface, settings, raw or str(settings)

    internet_ok, internet_detail = verify_internet(interface, logger)
    if not internet_ok:
        return False, interface, settings, internet_detail

    return True, interface, settings, internet_detail

def establish_session(logger=None):
    """Start QMI WDS only when disconnected, after WWAN/raw-IP preparation."""
    connected, status_output = packet_connected(logger)
    if connected:
        return True, "Existing packet session is already connected"

    interface = get_interface(logger)
    if not interface:
        return False, "Unable to dynamically detect QMI WWAN interface"

    # raw_ip must be set before the interface is brought up (see
    # ensure_wwan_raw_ip); bring_wwan_up() runs after it.
    raw_ok, raw_detail = ensure_wwan_raw_ip(interface, logger)
    if not raw_ok:
        return False, f"RAW-IP setup failed: {raw_detail}"

    ok, output = bring_wwan_up(interface, logger)
    if not ok:
        return False, output

    # --client-no-release-cid is required: without it, qmicli releases its
    # WDS client as soon as this invocation exits, which implicitly tears
    # the just-started packet session back down. That produces a connect/
    # disconnect flap on every call (visible as a repeating
    # "QMI DATA SESSION RECOVERY: DISCONNECTED" loop) instead of a session
    # that actually stays up.
    command = f"--client-no-release-cid --wds-start-network=apn={config.APN},ip-type=4"
    rc, output = qmi(command, logger, timeout=30)

    if rc == 0:
        return True, output

    # Verify WDS only; never call current-settings while disconnected.
    connected, verify_output = packet_connected(logger)
    if connected:
        return True, "Packet session became connected during WDS recovery"

    return False, output or verify_output



def qmi_prerequisites_ok(logger=None):
    """
    WAN recovery gate.

    WAN route/interface changes are forbidden unless:
      1. a current QMI control device exists,
      2. modem is ONLINE,
      3. SIM is READY,
      4. modem is registered,
      5. packet session is CONNECTED,
      6. current QMI IP/gateway/interface can be read.
    """
    device = find_qmi_device(logger)
    if not device:
        return False, "No usable QMI control device"

    rc, modem = qmi("--dms-get-operating-mode", logger)
    if rc != 0 or "online" not in modem.lower():
        return False, "Modem is not ONLINE"

    rc, sim = qmi("--uim-get-card-status", logger)
    if rc != 0 or "application state: 'ready'" not in sim.lower():
        return False, "SIM is not READY"

    rc, registration = qmi("--nas-get-serving-system", logger)
    text = registration.lower()
    registered = rc == 0 and any(
        word in text for word in ("registered", "home", "roaming", "current network")
    )
    if not registered:
        return False, "Network is not registered"

    connected, status = packet_connected(logger)
    if not connected:
        return False, "Packet session is not CONNECTED"

    return True, "QMI state healthy for WAN configuration"


def verify_internet(interface, logger=None):
    """Check Internet data connectivity using HTTPS, with ICMP retained for diagnostics."""

    if not getattr(config, "ENABLE_INTERNET_CHECK", True):
        return True, "Internet check disabled"

    import shutil
    details = []

    # ------------------------------------------------------------
    # ICMP tests - retained for diagnostics / packet-loss KPI.
    # Force the tests through the dynamically detected cellular WAN.
    # ------------------------------------------------------------
    if shutil.which("ping"):
        rc_ip, out_ip = run_cmd(
            ["ping", "-I", interface, "-c", "2", "-W", "3", "8.8.8.8"],
            timeout=8,
        )
        ip_ok = rc_ip == 0
        details.append(f"8.8.8.8={'OK' if ip_ok else 'FAIL'}")

        rc_google, out_google = run_cmd(
            ["ping", "-I", interface, "-c", "2", "-W", "3", "google.com"],
            timeout=8,
        )
        google_ok = rc_google == 0
        details.append(f"google.com={'OK' if google_ok else 'FAIL'}")

    else:
        ip_ok = False
        google_ok = False
        out_ip = ""
        out_google = ""

    # ------------------------------------------------------------
    # TCP/HTTPS test
    # ------------------------------------------------------------
    if not shutil.which("curl"):
        https_ok = False
        out_https = "curl unavailable"
        details.append("HTTPS=FAIL")
    else:
        rc_https, out_https = run_cmd(
            [
                "curl",
                "-4",
                "--interface", interface,
                "--connect-timeout", "5",
                "--max-time", "8",
                "-sS",
                "-o", "/dev/null",
                "-w", "%{http_code}",
                "https://www.google.com",
            ],
            timeout=10,
        )

        https_ok = rc_https == 0 and out_https in ("200", "204")
        details.append(f"HTTPS={'OK' if https_ok else 'FAIL'}")

    # ------------------------------------------------------------
    # WAN health decision
    #
    # ANY ONE test succeeds:
    #   WAN considered usable.
    #   No warning is printed.
    #
    # ALL THREE fail:
    #   Log warning and trigger WAN recovery.
    # ------------------------------------------------------------
    output = "; ".join(details)

    if ip_ok or google_ok or https_ok:
        return True, output

    # ------------------------------------------------------------
    # All three failed
    # ------------------------------------------------------------
    if logger:
        logger.write(
            "SYSTEM INTERNET CHECK",
            "ping 8.8.8.8 + ping google.com + HTTPS",
            output +
            f"\n8.8.8.8 OUTPUT:\n{out_ip}" +
            f"\nGOOGLE OUTPUT:\n{out_google}" +
            f"\nHTTPS OUTPUT:\n{out_https}",
            "WARNING",
        )

    return False, output


def ensure_wan(logger, retry_delay=5, max_attempts=None, initial_startup=False, reconnect_state=None):
    """
    Ensure WAN according to config.WAN_SESSION_MODE.

    MODEMMANAGER:
        ModemManager owns bearer and Linux WAN. No manual route configuration.

    QMI:
        ModemManager is stopped; qmicli owns WDS and this module configures
        the dynamically detected WWAN interface/routes.
    """
    mode = get_wan_session_mode()

    if mode == "MODEMMANAGER":
        attempt = 0
        while max_attempts is None or attempt < max_attempts:
            attempt += 1
            ok, interface, settings, detail = modemmanager_wan_check(logger)
            if ok:
                return True, interface, settings
            if logger:
                logger.write(
                    "WAN MODEMMANAGER CHECK",
                    "MM-owned WAN validation",
                    detail,
                    "WARNING",
                )
            if max_attempts is None or attempt < max_attempts:
                time.sleep(retry_delay)
        return False, "", {}

    # QMI mode
    if modemmanager_is_active(logger):
        ok, detail = stop_modemmanager(logger)
        if not ok:
            return False, "", {}

    attempt = 0
    if reconnect_state is None:
        reconnect_state = {"attempts": 0}

    def reconnect_allowed():
        if initial_startup:
            return True
        if not getattr(config, "AUTO_RECONNECT", True):
            return False
        limit = int(getattr(config, "MAX_RECONNECT_ATTEMPTS", 10))
        return limit == 0 or reconnect_state["attempts"] < limit

    def record_reconnect_attempt():
        if initial_startup:
            return
        reconnect_state["attempts"] += 1
        if logger:
            limit = int(getattr(config, "MAX_RECONNECT_ATTEMPTS", 10))
            logger.write(
                "WAN INTERNET RECONNECT ATTEMPT",
                "automatic cellular reconnect",
                f"Attempt {reconnect_state['attempts']}/{limit if limit else 'unlimited'}",
                "RECOVERY",
            )

    while max_attempts is None or attempt < max_attempts:
        attempt += 1
        try:
            device = find_qmi_device(logger)
            if not device:
                time.sleep(retry_delay)
                continue

            rc, modem = qmi("--dms-get-operating-mode", logger)
            if rc != 0 or "online" not in modem.lower():
                time.sleep(retry_delay)
                continue

            rc, sim = qmi("--uim-get-card-status", logger)
            if rc != 0 or "application state: 'ready'" not in sim.lower():
                time.sleep(retry_delay)
                continue

            rc, registration = qmi("--nas-get-serving-system", logger)
            reg_text = registration.lower()
            if rc != 0 or not any(
                x in reg_text for x in ("registered", "home", "roaming", "current network")
            ):
                time.sleep(retry_delay)
                continue

            # --------------------------------------------------
            # WDS state is checked FIRST.
            # --------------------------------------------------
            connected, status = packet_connected(logger)

            if not connected:
                if logger:
                    logger.write(
                        "QMI DATA SESSION RECOVERY",
                        "--wds-get-packet-service-status",
                        f"DISCONNECTED: {status}",
                        "RECOVERY",
                    )

                if not reconnect_allowed():
                    time.sleep(retry_delay)
                    continue

                record_reconnect_attempt()
                ok, response = establish_session(logger)
                if not ok:
                    if logger:
                        logger.write(
                            "QMI DATA SESSION RECOVERY",
                            f"--wds-start-network=apn={config.APN},ip-type=4",
                            response,
                            "FAILED",
                        )
                    time.sleep(retry_delay)
                    continue

                time.sleep(float(getattr(config, "QMI_SETTINGS_DELAY", 1.0)))

            # WDS MUST be connected before current-settings.
            connected, status = packet_connected(logger)
            if not connected:
                time.sleep(retry_delay)
                continue

            # --------------------------------------------------
            # Interface must exist and be UP before current-settings
            # is used to configure the Linux WAN.
            # --------------------------------------------------
            interface = get_interface(logger)
            if not interface:
                time.sleep(retry_delay)
                continue

            # In QMI mode, raw_ip is a Linux driver setting. It must be set
            # before the interface is brought up (see ensure_wwan_raw_ip).
            raw_ok, raw_detail = ensure_wwan_raw_ip(interface, logger)
            if not raw_ok:
                if logger:
                    logger.write("QMI RAW-IP", interface, raw_detail, "FAILED")
                time.sleep(retry_delay)
                continue

            ok, output = bring_wwan_up(interface, logger)
            if not ok:
                time.sleep(retry_delay)
                continue

            # NOW it is safe to ask for current settings.
            settings, valid, raw = get_current_settings(logger)
            if not valid:
                if logger:
                    logger.write(
                        "WAN PRECHECK",
                        "--get-wwan-iface + --wds-get-current-settings",
                        raw or str(settings),
                        "WARNING",
                    )
                time.sleep(retry_delay)
                continue

            current_ip = interface_ipv4(interface)
            current_route = route_for_interface(interface)
            route_ok = bool(
                re.search(
                    rf"default\s+via\s+{re.escape(settings['gateway'])}\b",
                    current_route,
                )
            )

            # --------------------------------------------------
            # If local WAN is already correct, test Internet.
            # If ping fails, repair the WWAN interface/WAN configuration
            # first. Do NOT start another WDS session while WDS is connected.
            # --------------------------------------------------
            if current_ip == settings["ip"] and route_ok:
                internet_ok, internet_detail = verify_internet(interface, logger)
                if internet_ok:
                    if not initial_startup:
                        reconnect_state["attempts"] = 0
                    return True, interface, settings

                if logger:
                    logger.write(
                        "WAN INTERNET RECOVERY",
                        "ping 8.8.8.8 + google.com",
                        f"Internet failed; repairing WWAN/WAN: {internet_detail}",
                        "RECOVERY",
                    )

            # --------------------------------------------------
            # WDS is connected but IP/route/ping is not healthy.
            # Reconfigure the dynamic WAN path, not the WDS session.
            # --------------------------------------------------
            if logger:
                logger.write(
                    "WAN CONFIGURATION RECOVERY",
                    "dynamic QMI IP/gateway/interface",
                    (
                        f"interface={interface}, "
                        f"QMI_IP={settings['ip']}, "
                        f"QMI_GW={settings['gateway']}, "
                        f"Linux_IP={current_ip}, "
                        f"Linux_ROUTE={current_route}"
                    ),
                    "RECOVERY",
                )

            ok, response = configure_interface(interface, settings, logger)
            if ok:
                healthy, verify_response = verify_wan(interface, settings, logger)
                if healthy:
                    internet_ok, internet_detail = verify_internet(interface, logger)
                    if internet_ok:
                        if not initial_startup:
                            reconnect_state["attempts"] = 0
                        return True, interface, settings
                    if logger:
                        logger.write(
                            "WAN INTERNET CHECK",
                            "ping 8.8.8.8 + google.com",
                            internet_detail,
                            "WARNING",
                        )
                elif logger:
                    logger.write(
                        "WAN CONFIGURATION RECOVERY",
                        "dynamic route verification",
                        verify_response,
                        "WARNING",
                    )
            elif logger:
                logger.write(
                    "WAN CONFIGURATION RECOVERY",
                    "dynamic Linux WAN configuration",
                    response,
                    "FAILED",
                )

            # If WDS has become disconnected during the WAN repair, the next
            # watchdog cycle goes back to the WDS-start branch above.
            time.sleep(retry_delay)

        except Exception as e:
            if logger:
                logger.write("WAN WATCHDOG", "", str(e), "FAILED")
            time.sleep(retry_delay)

    return False, "", {}



def watchdog_loop(logger, stop_event, interval=5):
    """
    Independent WAN/QMI watchdog.

    It checks QMI state first. A WAN configuration change is performed only
    when QMI is healthy and Linux WAN state is actually inconsistent.
    """
    reconnect_state = {"attempts": 0}
    while not stop_event.is_set():
        try:
            ok, iface, settings = ensure_wan(
                logger,
                retry_delay=interval,
                max_attempts=1,
                initial_startup=False,
                reconnect_state=reconnect_state,
            )

            if not ok and logger:
                logger.write(
                    "WAN WATCHDOG",
                    "QMI-first WAN health check",
                    "WAN not ready; waiting for next watchdog cycle",
                    "WARNING"
                )

        except Exception as e:
            if logger:
                logger.write("WAN WATCHDOG", "", str(e), "FAILED")

        stop_event.wait(interval)

# Internal WAN watchdog timing (not user configuration)
WAN_WATCHDOG_INTERVAL = 5.0
