import json
import subprocess
import time
import config

try:
    import paho.mqtt.client as mqtt
except ImportError:
    mqtt = None


class MQTT:
    def __init__(self, logger):
        self.client = None
        self.logger = logger
        self._last_discovery_publish = 0.0
        self._last_discovered_ipv6 = None

        if not config.MQTT_ENABLED:
            return

        if mqtt is None:
            logger.write(
                "MQTT",
                'python3 -c "import paho.mqtt.client"',
                "paho-mqtt is not installed",
                "FAILED"
            )
            return

        try:
            self.client = mqtt.Client()

            if config.MQTT_USERNAME:
                self.client.username_pw_set(
                    config.MQTT_USERNAME,
                    config.MQTT_PASSWORD
                )

            # Port 1883 is the non-TLS prototype broker path.
            # TLS configuration remains available when a TLS port is selected.
            if config.MQTT_PORT in (8883, 8884):
                import ssl
                self.client.tls_set(
                    cert_reqs=ssl.CERT_REQUIRED,
                    tls_version=ssl.PROTOCOL_TLS_CLIENT
                )

            self.client.connect(config.MQTT_HOST, config.MQTT_PORT, 60)
            self.client.loop_start()

            logger.write(
                "MQTT CONNECT",
                f"{config.MQTT_HOST}:{config.MQTT_PORT}",
                "Connected",
                "SUCCESS"
            )

        except Exception as e:
            logger.write("MQTT CONNECT", "", str(e), "FAILED")

    def publish(self, topic, data, retain=False):
        if not self.client:
            return

        try:
            self.client.publish(
                topic,
                json.dumps(data),
                qos=1,
                retain=retain
            )
        except Exception as e:
            self.logger.write("MQTT PUBLISH", "", str(e), "FAILED")

    @staticmethod
    def _current_ipv6(interface):
        """Return a preferred global IPv6 with infinite valid/preferred lifetimes.

        The address with valid_lft forever and preferred_lft forever is required.
        If multiple addresses match, prefer the one not marked mngtmpaddr, which
        selects the explicitly configured stable address in the current interface
        output rather than the stable-privacy temporary-address template.
        """
        if not interface:
            return ""

        try:
            result = subprocess.run(
                ["ip", "-6", "-o", "addr", "show", "dev", interface, "scope", "global"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=2,
                check=False,
            )
            if result.returncode != 0:
                return ""

            candidates = []
            for line in result.stdout.splitlines():
                parts = line.split()

                # Require both lifetime fields to be exactly "forever".
                try:
                    valid_lft = parts[parts.index("valid_lft") + 1]
                    preferred_lft = parts[parts.index("preferred_lft") + 1]
                    scope = parts[parts.index("scope") + 1]
                    address = parts[parts.index("inet6") + 1].split("/")[0]
                except (ValueError, IndexError):
                    continue

                if scope != "global":
                    continue
                if valid_lft != "forever" or preferred_lft != "forever":
                    continue
                if "temporary" in parts or "tentative" in parts or "deprecated" in parts:
                    continue
                if ":" not in address:
                    continue

                # Tie-break when more than one address has infinite lifetimes.
                # Prefer the explicit address without the mngtmpaddr template flag.
                priority = 1 if "mngtmpaddr" in parts else 0
                candidates.append((priority, address))

            if not candidates:
                return ""

            candidates.sort(key=lambda candidate: candidate[0])
            return candidates[0][1]
        except Exception:
            return ""

    def publish_discovery(self, interface, force=False):
        """Publish Drone-ID and current dynamic IPv6 without changing QMI/WAN flow.

        The existing monitoring loop calls this method; it is internally throttled.
        A changed IPv6 address is published immediately. The retained message lets a
        late subscriber discover the latest address.
        """
        if not self.client:
            return

        now = time.monotonic()
        interval = float(getattr(config, "MQTT_DISCOVERY_INTERVAL", 10.0))
        if not force and (now - self._last_discovery_publish) < interval:
            return

        ipv6 = self._current_ipv6(interface)
        if not force and ipv6 == self._last_discovered_ipv6 and ipv6:
            self._last_discovery_publish = now
            return

        payload = {
            "version": 1,
            "drone_id": config.DRONE_ID,
            "ipv6": ipv6,
            "status": "online" if ipv6 else "ipv6_unavailable",
            "timestamp": time.time(),
        }

        topic = f"{config.MQTT_DISCOVERY_ROOT}/{config.DRONE_ID}/discovery"
        self.publish(topic, payload, retain=True)
        self._last_discovery_publish = now
        self._last_discovered_ipv6 = ipv6

    def close(self):
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()
