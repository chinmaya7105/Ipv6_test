#!/usr/bin/env python3
import glob
import re
import subprocess
import time
from pymavlink import mavutil
import socket

MAVLINK_RECEIVE_TIMEOUT = 3.0
MAVLINK_WATCHDOG_TIMEOUT = 10.0
BAUDRATE = 115200
ACM_GLOB = '/dev/ttyACM*'
MESSAGE_TYPES = ['GLOBAL_POSITION_INT', 'GPS_RAW_INT', 'ATTITUDE', 'VFR_HUD']


def get_udp_listening_ports():
    """Discover locally listening UDP ports; no MAVProxy port is hard-coded."""
    ports = set()
    try:
        result = subprocess.run(
            ['ss', '-u', '-ln'],
            capture_output=True, text=True, timeout=2.0, check=False
        )
        pattern = re.compile(r'(?:127\.0\.0\.1|0\.0\.0\.0|\*|\[::\]|::):(\d+)$')
        for line in result.stdout.splitlines():
            fields = line.split()
            if len(fields) < 5:
                continue
            match = pattern.search(fields[4])
            if match:
                ports.add(int(match.group(1)))
    except Exception as exc:
        print(f'[WARNING] MAVLINK UDP discovery failed: {exc}')
    return sorted(ports)

def test_mavlink_connection(connection, source):
    """Return True only when the candidate actually provides a MAVLink heartbeat."""
    try:
        print(f'[RUNNING] MAVLINK DEVICE TEST: Waiting for MAVLink heartbeat on {source}')
        heartbeat = connection.wait_heartbeat(timeout=MAVLINK_RECEIVE_TIMEOUT)
        if heartbeat is not None:
            print(
                f'[OK] MAVLink heartbeat received: {source} '
                f'(system={connection.target_system}, component={connection.target_component})'
            )
            return True
        print(f'[FAILED] MAVLINK DEVICE TEST: No heartbeat within {MAVLINK_RECEIVE_TIMEOUT:.0f} seconds')
    except Exception as exc:
        print(f'[FAILED] MAVLINK DEVICE TEST: {source}: {exc}')
    return False


def detect_mavlink_udp():
    """Discover local UDP listeners and select the first one carrying MAVLink."""
    ports = get_udp_listening_ports()
    if not ports:
        print('[INFO] No locally listening UDP ports detected')
        return None, None

    print(f'[MAVLINK] Dynamically detected UDP ports: {ports}')

    for port in ports:
        source = f'UDP:127.0.0.1:{port}'
        connection = None
        try:
            connection = mavutil.mavlink_connection(
                f'udpin:127.0.0.1:{port}', autoreconnect=False
            )
            if test_mavlink_connection(connection, source):
                return source, connection
        except Exception as exc:
            print(f'[WARNING] {source} is not a working MAVLink source: {exc}')
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass
    return None, None


def detect_mavlink_acm():
    """Fallback: discover /dev/ttyACM* and select the first working MAVLink port."""
    ports = sorted(glob.glob(ACM_GLOB))
    if not ports:
        print('[WARNING] No ACM serial device detected')
        return None, None

    for port in ports:
        print(f'[CHECK] Trying MAVLink USB port: {port}')
        connection = None
        try:
            connection = mavutil.mavlink_connection(
                port, baud=BAUDRATE, autoreconnect=False
            )
            if test_mavlink_connection(connection, port):
                return port, connection
        except Exception as exc:
            print(f'[WARNING] {port} is not a working MAVLink port: {exc}')
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass
    return None, None


def detect_mavlink_port():
    """UDP MAVLink first, then direct USB ACM fallback."""
    print('[MAVLINK] Searching for MAVLink UDP source...')
    source, connection = detect_mavlink_udp()
    if connection is not None:
        print(f'[MAVLINK] Selected source: {source}')
        return source, connection

    print('[MAVLINK] No working MAVLink UDP source found; falling back to USB ACM')
    source, connection = detect_mavlink_acm()
    if connection is not None:
        print(f'[MAVLINK] Selected source: {source}')
    return source, connection


def monitor_mavlink(port, connection):
    last_message_time = time.monotonic()
    print(f'[OK] MAVLink monitoring started on {port}')

    while True:
        try:
            msg = connection.recv_match(
                type=MESSAGE_TYPES, blocking=True, timeout=MAVLINK_RECEIVE_TIMEOUT
            )
            now = time.monotonic()
            if msg is not None:
                last_message_time = now
                print(msg)
                continue

            silence = now - last_message_time
            if silence >= MAVLINK_WATCHDOG_TIMEOUT:
                print(
                    f'[ERROR] MAVLINK SERVICE: Telemetry reception stopped for {silence:.1f} seconds'
                )
                return False
        except Exception as exc:
            print(f'[ERROR] MAVLINK SERVICE: {exc}')
            return False


def main():
    print('MAVLink telemetry test started')
    print('Dynamic MAVLink discovery enabled: UDP first, USB ACM fallback')

    while True:
        port, connection = detect_mavlink_port()

        if connection is None:
            print('[WARNING] MAVLINK SERVICE: No working UDP or ACM MAVLink source')
            print('[RECOVERY] Retrying MAVLink discovery in 1 second...')
            time.sleep(1.0)
            continue

        try:
            healthy = monitor_mavlink(port, connection)
        finally:
            try:
                connection.close()
            except Exception:
                pass

        if not healthy:
            print('[RECOVERY] MAVLINK SERVICE: Releasing failed source')
            print('[RECOVERY] MAVLINK SERVICE: Rediscovering MAVLink source...')
            time.sleep(1.0)


if __name__ == '__main__':
    main()
